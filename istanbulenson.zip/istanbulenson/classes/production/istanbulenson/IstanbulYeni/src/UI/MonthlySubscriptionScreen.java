package UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import CardTypes.Cards;
import Database.UserDatabase;
import Database.CardDatabase;

public class MonthlySubscriptionScreen extends JFrame {
    private final JComboBox<String> cardComboBox;
    private final JButton loadSubscriptionButton;
    private final JLabel resultLabel;
    private final UserDatabase userDatabase = new UserDatabase();
    private final CardDatabase cardDatabase = new CardDatabase();

    private Map<String, Cards> cardMap = new HashMap<>(); // Kartları ve ID'lerini tutacak map

    public MonthlySubscriptionScreen() {
        super("Aylık Abonman Yükleme");

        // Ana pencere düzeni
        setLayout(new BorderLayout());

        // Üst panel: Geri butonu
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton backButton = new JButton("Geri");
        backButton.addActionListener(e -> {
            dispose();  // Mevcut pencereyi kapat
            new TransactionPage().setVisible(true);  // TransactionPage sayfasını aç
        });
        topPanel.add(backButton);
        add(topPanel, BorderLayout.NORTH);

        // Merkez panel: Ana içerik
        JPanel centerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Bileşenler arasındaki boşluk

        // Kart seçimi etiketi ve combo box
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        centerPanel.add(new JLabel("Kart Seçin:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        cardComboBox = new JComboBox<>();
        cardComboBox.setEnabled(false); // İlk başta pasif
        centerPanel.add(cardComboBox, gbc);

        // Kartları getir butonu
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton fetchCardsButton = new JButton("Kartları Getir");
        fetchCardsButton.addActionListener(this::fetchCardsForCurrentUser);
        centerPanel.add(fetchCardsButton, gbc);

        // Aylık abonman yükle butonu
        gbc.gridy = 2;
        loadSubscriptionButton = new JButton("Aylık Abonman Yükle");
        loadSubscriptionButton.setEnabled(false); // İlk başta pasif
        loadSubscriptionButton.addActionListener(this::loadMonthlySubscription);
        centerPanel.add(loadSubscriptionButton, gbc);

        // Sonuç etiketi
        gbc.gridy = 3;
        resultLabel = new JLabel();
        resultLabel.setHorizontalAlignment(SwingConstants.CENTER);
        centerPanel.add(resultLabel, gbc);

        add(centerPanel, BorderLayout.CENTER);

        // Pencere ayarları
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Pencereyi ekranın ortasına yerleştirir
    }

    private void fetchCardsForCurrentUser(ActionEvent e) {
        // Geçerli kullanıcının emailinden ID'yi al
        String email = UserSession.getCurrentUserEmail();
        String userId = userDatabase.getUserIdByEmail(email);

        if (userId == null || userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Kullanıcı ID alınamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
            cardComboBox.setEnabled(false);
            loadSubscriptionButton.setEnabled(false);
            return;
        }

        // Kullanıcıya ait kartları al
        List<Cards> userCards = cardDatabase.getCardsByUserId(userId);
        if (userCards == null || userCards.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Bu kullanıcıya ait kart bulunamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
            cardComboBox.setEnabled(false);
            loadSubscriptionButton.setEnabled(false);
            return;
        }

        // Kartları combo box'a ekle
        cardComboBox.removeAllItems();
        cardMap.clear();  // Map'i temizle
        for (Cards card : userCards) {
            // Kart numarasını daha anlaşılır şekilde gösterelim
            cardComboBox.addItem("Kart: " + card.getCardNumber() + " - Tip: " + card.getCardType());
            cardMap.put(card.toString(), card);  // String'e karşılık gelen Card nesnesini Map'e ekliyoruz
        }
        cardComboBox.setEnabled(true);
        loadSubscriptionButton.setEnabled(true);

        // Kullanıcı ID'sini abonman yükleme işlemi için sakla
        loadSubscriptionButton.putClientProperty("userId", userId);
    }

    private void loadMonthlySubscription(ActionEvent e) {
        // Seçilen kartın String değerini al
        String selectedCardString = (String) cardComboBox.getSelectedItem();
        if (selectedCardString == null) {
            JOptionPane.showMessageDialog(this, "Lütfen bir kart seçin!", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // String'den Card nesnesine ulaşmak için Map kullanıyoruz
        Cards selectedCard = cardMap.get(selectedCardString);
        if (selectedCard == null) {
            JOptionPane.showMessageDialog(this, "Seçilen kart geçersiz.", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Kart ID'sini al
        String selectedCardId = selectedCard.getCardNumber();

        // Kullanıcı ID'yi buton özelliğinden al
        String userId = (String) loadSubscriptionButton.getClientProperty("userId");
        if (userId == null || userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Kullanıcı ID bulunamadı. Lütfen kartları tekrar getirin.", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Seçilen karta aylık abonman yükle
            cardDatabase.updateSubscriptionStatus(userId, selectedCardId, true);
            resultLabel.setText("Abonman başarıyla yüklendi: " + selectedCard.getCardNumber());
            resultLabel.setForeground(Color.GREEN);
        } catch (Exception ex) {
            ex.printStackTrace();
            resultLabel.setText("Abonman yüklenemedi: " + selectedCard.getCardNumber());
            resultLabel.setForeground(Color.RED);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // MonthlySubscriptionScreen nesnesini başlat
                MonthlySubscriptionScreen screen = new MonthlySubscriptionScreen();
                screen.setVisible(true);
            }
        });
    }
}
