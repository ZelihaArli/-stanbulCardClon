package UI;

import CardTypes.Cards;
import Database.CardDatabase;
import Database.UserDatabase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class UpdateBalancePage extends JFrame {

    private final CardDatabase cardDatabase;

    public UpdateBalancePage() {
        setTitle("Update Card Balance");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // CardDatabase nesnesini oluşturuyoruz
        cardDatabase = new CardDatabase();

        UserDatabase userDatabase = new UserDatabase();
        String email = UserSession.getCurrentUserEmail();
        String userId = userDatabase.getUserIdByEmail(email);

        // Ana panel ve layout
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(8, 1, 10, 10));

        // Kullanıcının sahip olduğu kartları almak
        List<Cards> userCards = cardDatabase.getCardsByUserId(userId);

        // Kartlar için JComboBox
        JComboBox<String> cardComboBox = new JComboBox<>();
        for (Cards card : userCards) {
            cardComboBox.addItem(card.toString());  // Kart bilgilerini string formatında ekliyoruz
        }

        // Bakiyeler için seçenekler
        JComboBox<String> balanceComboBox = new JComboBox<>(new String[]{"10 TL", "50 TL", "100 TL", "200 TL", "500 TL"});
        JTextField customBalanceField = new JTextField();  // Elle bakiye girişi için alan

        // Yapılacak işlemler
        JButton updateButton = new JButton("Update Balance");
        JButton backButton = new JButton("Back");

        // Bakiye güncellemeyi gerçekleştirecek buton
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedCardString = (String) cardComboBox.getSelectedItem();
                if (selectedCardString == null || !selectedCardString.contains(" ")) {
                    JOptionPane.showMessageDialog(UpdateBalancePage.this,
                            "Invalid card format. Please select a valid card.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String cardNumber = null;
                String cardName="";

                try {
                    // Boşluklarla ayrılmış diziyi parçala
                    String[] parts = selectedCardString.split(" ");  // Burada boşlukla ayırıyoruz

                    // Dizinin uzunluğunu kontrol et ve üçüncü öğeyi al
                    if (parts.length > 3) {
                        cardNumber = parts[3].trim();  // Üçüncü öğeyi al ve boşlukları temizle
                        cardName=parts[1].trim();
                    }

                    // Eğer kart numarası hala null ise, hata fırlat
                    if (cardNumber == null || cardNumber.isEmpty()) {
                        throw new IllegalArgumentException("Invalid card data format.");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(UpdateBalancePage.this,
                            "Error processing card data. Please select a valid card.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return; // İşlemi durdur
                }

                double newBalance = 0;

                // Seçilen bakiyeyi al
                String selectedBalance = (String) balanceComboBox.getSelectedItem();
                if (selectedBalance != null) {
                    switch (selectedBalance) {
                        case "10 TL":
                            newBalance = 10;
                            break;
                        case "50 TL":
                            newBalance = 50;
                            break;
                        case "100 TL":
                            newBalance = 100;
                            break;
                        case "200 TL":
                            newBalance = 200;
                            break;
                        case "500 TL":
                            newBalance = 500;
                            break;
                    }
                }

                // Elle girilen bakiye varsa, onu kullan
                if (!customBalanceField.getText().isEmpty()) {
                    try {
                        newBalance = Double.parseDouble(customBalanceField.getText());
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(UpdateBalancePage.this,
                                "Invalid amount. Please enter a valid number.",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // Bakiye güncellemeyi yap
                try {
                    cardDatabase.updateCardBalance(userId, cardName,cardNumber, newBalance); // CardDatabase'den bakiye güncelleme
                    System.out.println(userId + " " + cardNumber + " " + newBalance);

                    JOptionPane.showMessageDialog(UpdateBalancePage.this,
                            "Balance updated successfully!",
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(UpdateBalancePage.this,
                            "An error occurred while updating the balance. Please try again.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    System.out.println(userId + " " + cardNumber + " " + newBalance);
                }
            }
        });

        // Geri butonu
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                // Önceki sayfaya dön
                new MainUI().setVisible(true);
            }
        });

        // UI düzenini oluştur
        mainPanel.add(new JLabel("Select card to update:"));
        mainPanel.add(cardComboBox);
        mainPanel.add(new JLabel("Select balance to load:"));
        mainPanel.add(balanceComboBox);
        mainPanel.add(new JLabel("Or enter a custom balance:"));
        mainPanel.add(customBalanceField);
        mainPanel.add(updateButton);
        mainPanel.add(backButton);

        add(mainPanel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new UpdateBalancePage();
            }
        });
    }
}
