package UI;

import Database.UserDatabase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TransactionPage extends JFrame {

    public TransactionPage() {
        setTitle("Transaction Page");
        setSize(700, 500);  // Sayfa boyutunu biraz küçülttüm
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);


        UserDatabase userDatabase = new UserDatabase();
        String email = UserSession.getCurrentUserEmail();
        String userId = userDatabase.getUserIdByEmail(email);

        // Başlık paneli

        JLabel titleLabel = new JLabel("İşlemler");
        titleLabel.setBounds(80,50,100,30);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 25));
        add(titleLabel);

        // Geri butonu
        JButton backButton = new JButton("Geri");
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        backButton.setBounds(550,10,100,30);
        backButton.setFocusPainted(false); // Butonun etrafındaki boşluğu ayarlıyoruz
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Geri butonuna tıklandığında, önceki sayfaya dön
                new MainUI().setVisible(true);  // Önceki sayfaya geri dön
                dispose();  // Bu sayfayı kapat
            }
        });

        // Geri butonunu sağ üst köşeye yerleştirmek için
        add(backButton);  // Geri butonunu sağ üst köşeye yerleştiriyoruz


        // Kart Başvurusu butonu ekleme
        JButton cardApplicationButton = new JButton("Kart Başvurusu");
        cardApplicationButton.setBounds(80,110,200,100);
        cardApplicationButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
          // Butona ikon ekledik
        cardApplicationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CardApplicationPage().setVisible(true);  // Kart başvurusu sayfasını aç
                dispose();  // Bu sayfayı kapat
            }
        });

        // Diğer butonları ekleyelim
        JButton loadTLButton = new JButton("TL Yükle");
        loadTLButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loadTLButton.setBounds(340,110,200,100);

        loadTLButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new UpdateBalancePage().setVisible(true);  // Kart başvurusu sayfasını aç
                dispose();
            }
        });

        JButton subscriptionLoadButton = new JButton("Abonman Yükle");
        subscriptionLoadButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        subscriptionLoadButton.setBounds(80,250,200,100);

        subscriptionLoadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MonthlySubscriptionScreen().setVisible(true);
                dispose();
            }
        });


        JButton myApplicationsButton = new JButton("Başvurularım");
        myApplicationsButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        myApplicationsButton.setBounds(340,250,200,100);



        // Butonları ekleyelim
        add(loadTLButton);
        add(subscriptionLoadButton);
        add(myApplicationsButton);
        add(cardApplicationButton);  // Kart başvurusu butonunu ekleyelim

         // Butonları sayfaya ekle

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TransactionPage();  // Transaction sayfasını başlat
            }
        });
    }
}
