package UI;

import javax.swing.*;
import java.awt.*;

public class RoundedButton extends JButton {
    private final int borderRadius;

    public RoundedButton(String text, int borderRadius) {
        super(text);
        this.borderRadius = borderRadius;

        // Görsel düzenlemeler
        setFont(new Font("Segoe UI", Font.BOLD, 14));
        setForeground(Color.BLACK);
        setBackground(Color.LIGHT_GRAY);
        setFocusPainted(false);
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Arka plan rengini çiz
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), borderRadius, borderRadius);

        super.paintComponent(g);
    }

    @Override
    protected void paintBorder(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(Color.GRAY);
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, borderRadius, borderRadius);
    }
}
