package UI;

public class EditProfilePage {
}
