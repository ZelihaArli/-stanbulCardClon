package UI;

import javax.swing.*;
import java.awt.*;
import java.util.List;

import CardTypes.Cards;
import Database.UserDatabase;
import Database.CardDatabase;


public class AccountInfoPage extends JFrame {
    private JLabel userIdLabel;
    private JLabel userEmailLabel;
    private JLabel accountBalanceLabel;
    private JButton backButton;
    private JButton editProfileButton;
    private JButton showCardsButton;

    private UserDatabase userDatabase = new UserDatabase();
    private CardDatabase cardDatabase = new CardDatabase();

    public AccountInfoPage() {
        super("Account Information");

        // Ana pencere düzeni
        setLayout(new BorderLayout());

        // Üst panel: Geri butonu
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        backButton = new JButton("Geri");
        backButton.addActionListener(e -> {
            dispose();  // Mevcut pencereyi kapat
            new TransactionPage().setVisible(true);  // TransactionPage sayfasını aç
        });
        topPanel.add(backButton);
        add(topPanel, BorderLayout.NORTH);

        // Merkez panel: Hesap bilgilerini gösteren alan
        JPanel centerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Bileşenler arasındaki boşluk

        // Kullanıcı ID etiketi ve değeri
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        centerPanel.add(new JLabel("Kullanıcı ID:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        userIdLabel = new JLabel();
        centerPanel.add(userIdLabel, gbc);

        // Kullanıcı e-posta etiketi ve değeri
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        centerPanel.add(new JLabel("E-posta:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        userEmailLabel = new JLabel();
        centerPanel.add(userEmailLabel, gbc);

        // Hesap bakiyesi etiketi ve değeri
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.EAST;
        centerPanel.add(new JLabel("Hesap Bakiyesi:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        accountBalanceLabel = new JLabel();
        centerPanel.add(accountBalanceLabel, gbc);

        // Kartları göster butonu
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        showCardsButton = new JButton("Kartları Göster");
        showCardsButton.addActionListener(e -> showCards());
        centerPanel.add(showCardsButton, gbc);

        // Profil düzenle butonu
        gbc.gridy = 4;
        editProfileButton = new JButton("Profili Düzenle");
        editProfileButton.addActionListener(e -> editProfile());
        centerPanel.add(editProfileButton, gbc);

        // Merkez paneli ekle
        add(centerPanel, BorderLayout.CENTER);

        // Pencere ayarları
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Pencereyi ekranın ortasına yerleştirir

        // Kullanıcı bilgilerini yükle
        loadAccountInfo();
    }

    // Hesap bilgilerini yükleyen metot
    private void loadAccountInfo() {
        // Kullanıcı ID'sini ve e-posta adresini UserSession üzerinden alıyoruz
        String email = UserSession.getCurrentUserEmail();
        String userId = userDatabase.getUserIdByEmail(email);

        if (userId != null && !userId.isEmpty()) {
            userIdLabel.setText(userId);
            userEmailLabel.setText(email);

            // Hesap bakiyesini al
            double balance = cardDatabase.getBalanceForUser(userId); // CardDatabase'deki geçerli metodu çağırıyoruz
            accountBalanceLabel.setText(String.format("%.2f", balance));
        } else {
            JOptionPane.showMessageDialog(this, "Kullanıcı bilgileri alınamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Kartları gösterme işlemi
    private void showCards() {
        String userId = userIdLabel.getText();
        if (userId == null || userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Geçerli kullanıcı bulunamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Kartları göstermek için CardDatabase'ten kartları al
        List<Cards> userCards = cardDatabase.getCardsByUserId(userId);
        if (userCards != null && !userCards.isEmpty()) {
            StringBuilder cardList = new StringBuilder("Kullanıcıya ait kartlar:\n");
            for (Cards card : userCards) {
                cardList.append(card.toString()).append("\n");
            }
            JOptionPane.showMessageDialog(this, cardList.toString(), "Kullanıcı Kartları", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Bu kullanıcıya ait kart bulunamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Profili düzenleme işlemi
    private void editProfile() {
        String userId = userIdLabel.getText();
        if (userId == null || userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Geçerli kullanıcı bulunamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Profil düzenleme sayfasına yönlendir
        //new EditProfilePage().setVisible(true);
        this.dispose(); // Mevcut sayfayı kapat
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // AccountInfoPage nesnesini başlat
            AccountInfoPage page = new AccountInfoPage();
            page.setVisible(true);
        });
    }
}
