//import UI.MainUI;
//
//import javax.swing.*;
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.io.IOException;
//
//public class applicationinprogresspage extends JFrame {
//
//    public applicationinprogresspage(String userId) {
//        setTitle("Başvuru Durumu");
//        setSize(500, 400);
//        setLocationRelativeTo(null);
//
//        JPanel mainPanel = new JPanel();
//        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
//
//        // Başvuru durumu etiketini ekliyoruz
//        JLabel statusLabel = new JLabel("Başvurunuz Bekliyor...");
//        mainPanel.add(statusLabel);
//
//        // Geri butonu
//        JButton backButton = new JButton("Geri");
//        backButton.addActionListener(e -> {
//            // Ana sayfayı veya önceki sayfayı aç
//            new MainUI().setVisible(true); // Örneğin, ana sayfayı açıyoruz
//            dispose(); // Bu sayfayı kapatıyoruz
//        });
//        mainPanel.add(backButton);
//
//        // Dosyadaki başvuruyu kontrol etme
//        boolean found = false;
//        try (BufferedReader reader = new BufferedReader(new FileReader("bekleyen_basvurular.txt"))) {
//            String line;
//            while ((line = reader.readLine()) != null) {
//                String[] parts = line.split(",");
//                String id = parts[0];
//                String cardType = parts[1];
//                String applicationStatus = parts[2]; // Başvuru durumu
//
//                // Eğer kullanıcıya ait başvuru varsa, durumu göster
//                if (id.equals(userId)) {
//                    statusLabel.setText("Başvurunuz: " + cardType + " - Durum: " + applicationStatus);
//                    found = true;
//                    break;
//                }
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        // Başvuru bulunamazsa, mesaj göster
//        if (!found) {
//            statusLabel.setText("Başvurunuz Bulunamadı.");
//        }
//
//        add(mainPanel);
//        setVisible(true);
//    }
//}
//public void main(String[] args) {
//    new applicationinprogresspage("12345"); // Kullanıcı ID'si örneği
//}
