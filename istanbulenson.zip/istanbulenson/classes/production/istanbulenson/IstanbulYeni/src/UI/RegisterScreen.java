package UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import Database.UserDatabase;

public class RegisterScreen extends JFrame {
    private final JTextField idField, firstNameField, lastNameField, birthDateField, phoneField, emailField;
    private final JPasswordField passwordField; // Password field added
    private final JCheckBox nonCitizenCheckBox;
    private final JButton saveButton;
    private final UserDatabase userDatabase;
    private final RoundedButton backButton;

    public RegisterScreen() {
        super("istanbul");
        getContentPane().setBackground(Color.white);
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        ImageIcon icon = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");
        setIconImage(icon.getImage());

        ImageIcon image = new ImageIcon("C:/Users/Taha/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/sende.jpg");
        JLabel imageLabel = new JLabel(image);
        imageLabel.setBounds(750, 1, 1000, 600);
        add(imageLabel);

        userDatabase = new UserDatabase();

        setLayout(null);

        // Back Button
        
        backButton = new RoundedButton("Geri Dön", 15);
        backButton.setBounds(10, 10, 80, 30);
        backButton.setFont(new Font("Segoe UI Black", Font.BOLD, 8));
        backButton.setFocusPainted(false);
        backButton.setBorder(new RoundedBorder(15)); // Yuvarlak kenarlık
        backButton.addActionListener(e -> {
            new LoginScreen().setVisible(true);
            dispose();
        });
        add(backButton);

        // ID Number
        JLabel idLabel = new JLabel("ID Number:");
        idLabel.setBounds(10, 70, 120, 25);
        idLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        add(idLabel);

        idField = new JTextField();
        idField.setBounds(180, 70, 200, 25);
        idField.setBorder(new RoundedBorder(15)); // Yuvarlak kenarlık
        add(idField);

        // "I am not a citizen" checkbox
        nonCitizenCheckBox = new JCheckBox("I am not a citizen");
        nonCitizenCheckBox.setBounds(180, 98, 200, 20);
        nonCitizenCheckBox.setBackground(Color.white);
        nonCitizenCheckBox.addActionListener(e -> {
            if (nonCitizenCheckBox.isSelected()) {
                idField.setText("");
                idField.setEnabled(false);
            } else {
                idField.setEnabled(true);
            }
        });
        add(nonCitizenCheckBox);

        // First Name
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setBounds(10, 120, 120, 25);
        firstNameLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        add(firstNameLabel);

        firstNameField = new JTextField();
        firstNameField.setBounds(180, 120, 200, 25);
        firstNameField.setBorder(new RoundedBorder(15)); // Yuvarlak kenarlık
        add(firstNameField);

        // Last Name
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setBounds(10, 160, 120, 25);
        lastNameLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        add(lastNameLabel);

        lastNameField = new JTextField();
        lastNameField.setBounds(180, 160, 200, 25);
        lastNameField.setBorder(new RoundedBorder(15)); // Yuvarlak kenarlık
        add(lastNameField);

        // Birth Date
        JLabel birthDateLabel = new JLabel("Birth Date (YYYY-MM-DD):");
        birthDateLabel.setBounds(10, 200, 200, 25);
        birthDateLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 12));
        add(birthDateLabel);

        birthDateField = new JTextField();
        birthDateField.setBounds(180, 200, 200, 25);
        birthDateField.setBorder(new RoundedBorder(15)); // Yuvarlak kenarlık
        add(birthDateField);

        // Phone Number
        JLabel phoneLabel = new JLabel("Phone Number:");
        phoneLabel.setBounds(10, 240, 120, 25);
        phoneLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        add(phoneLabel);

        phoneField = new JTextField();
        phoneField.setBounds(180, 240, 200, 25);
        phoneField.setBorder(new RoundedBorder(15)); // Yuvarlak kenarlık
        add(phoneField);

        // Email
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(10, 280, 120, 25);
        emailLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(180, 280, 200, 25);
        emailField.setBorder(new RoundedBorder(15)); // Yuvarlak kenarlık
        add(emailField);

        // Password
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10, 320, 120, 25);
        passwordLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(180, 320, 200, 25);
        passwordField.setBorder(new RoundedBorder(15)); // Yuvarlak kenarlık
        add(passwordField);

        // Save Button

        saveButton = new RoundedButton("Save", 15);
        saveButton.setBounds(320, 380, 100, 30);
        saveButton.addActionListener(this::saveUserInformation);
        add(saveButton);



    }



    private void saveUserInformation(ActionEvent e) {
        // Get values from fields
        String id = idField.getText().trim();
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String birthDate = birthDateField.getText().trim();
        String phone = phoneField.getText().trim();
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        // Check for empty fields
        if (firstName.isEmpty() || lastName.isEmpty() || birthDate.isEmpty() || phone.isEmpty() || email.isEmpty() ||
                password.isEmpty() || (!nonCitizenCheckBox.isSelected() && id.isEmpty())) {
            JOptionPane.showMessageDialog(this, "All fields must be filled out!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Password validation
        String passwordRegex = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$";
        if (!password.matches(passwordRegex)) {
            JOptionPane.showMessageDialog(this, "Password must be at least 8 characters long, containing both letters and numbers.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate ID, phone, email, and birthdate
        if (!nonCitizenCheckBox.isSelected() && !id.matches("\\d{11}")) {
            JOptionPane.showMessageDialog(this, "ID number must be 11 digits!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int age;
        try {
            LocalDate birthDateParsed = LocalDate.parse(birthDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            age = Period.between(birthDateParsed, LocalDate.now()).getYears();
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Invalid birth date format! (Format: YYYY-MM-DD)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!phone.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(this, "Phone number must be 10 digits!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(this, "Invalid email format!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String tcidno = nonCitizenCheckBox.isSelected() ? "Non-citizen" : id;

        if (!nonCitizenCheckBox.isSelected() && userDatabase.getUserById(id) != null) {
            JOptionPane.showMessageDialog(this, "User with this ID already exists!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        userDatabase.addUser(tcidno, firstName, lastName, birthDate, phone, email, password);

        JOptionPane.showMessageDialog(this, "User successfully registered!");

        clearFields();
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    private void clearFields() {
        idField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        birthDateField.setText("");
        phoneField.setText("");
        emailField.setText("");
        passwordField.setText("");
        nonCitizenCheckBox.setSelected(false);
        idField.setEnabled(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RegisterScreen form = new RegisterScreen();
            form.setVisible(true);
        });
    }
}