package UI;

import Database.CardDatabase;
import Database.UserDatabase; // UserDatabase'i ekliyoruz
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class CardApplicationPage extends JFrame {

    public CardApplicationPage() {
        setTitle("Card Application");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Ana panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10)); // BorderLayout ile düzenleme yapıyoruz
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Başlık paneli
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS)); // Başlıkları dikey hizalamak için BoxLayout kullanıyoruz

        // Başlık ekleme
        JLabel titleLabel = new JLabel("Kart başvurusu", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titlePanel.add(titleLabel); // Başlık paneli ekle

        // Alt başlık ekleme
        JLabel subtitleLabel = new JLabel("Hangi karta başvurmak istersin?", SwingConstants.CENTER);
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        titlePanel.add(subtitleLabel); // Alt başlık paneli ekle

        // Geri butonu
        JButton backButton = new JButton("Geri");
        backButton.setFont(new Font("Arial", Font.PLAIN, 12)); // Buton fontunu küçük yapıyoruz
        backButton.setPreferredSize(new Dimension(80, 30)); // Buton boyutunu küçültüyoruz
        backButton.addActionListener(e -> {
            // Ana sayfayı göster ve mevcut sayfayı kapat
            new MainUI().setVisible(true);
            dispose();
        });

        // Geri butonunu sağ üst köşeye yerleştiriyoruz
        JPanel backButtonPanel = new JPanel();
        backButtonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT)); // Sağ üst köşeye hizala
        backButtonPanel.add(backButton);

        // Kart butonlarını resim ve isimle birlikte ekleme
        JPanel cardPanel = new JPanel();
        cardPanel.setLayout(new BoxLayout(cardPanel, BoxLayout.Y_AXIS)); // Kart butonlarını dikey olarak ekliyoruz
        addCardOption(cardPanel, "Ücretsiz Kart", "free_card.png");
        addCardOption(cardPanel, "İndirimli Kart", "discount_card.png");
        addCardOption(cardPanel, "Mavi Kart", "blue_card.png");
        addCardOption(cardPanel, "Umumi Kart", "anonim_card.png"); // Anonim kart eklendi

        // Başlık paneli ve geri butonu panelini ana panele ekle
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(backButtonPanel, BorderLayout.NORTH); // Geri butonunu başlık paneliyle birlikte ekliyoruz
        mainPanel.add(cardPanel, BorderLayout.CENTER);

        // Ana paneli pencereye ekle
        add(mainPanel);
        setVisible(true);
    }

    /**
     * Bir kart seçeneğini (resim ve başvuru butonu) ana panele ekler.
     */
    private void addCardOption(JPanel panel, String cardName, String imagePath) {
        JPanel cardPanel = new JPanel();
        cardPanel.setLayout(new BorderLayout(10, 10));
        cardPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        // Kart resmi
        JLabel cardImage = new JLabel();
        cardImage.setHorizontalAlignment(SwingConstants.CENTER);
        ImageIcon imageIcon = new ImageIcon(imagePath); // Resim dosyasını yüklüyor
        Image scaledImage = imageIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        cardImage.setIcon(new ImageIcon(scaledImage));

        // Kart ismi
        JLabel cardLabel = new JLabel(cardName, SwingConstants.CENTER);
        cardLabel.setFont(new Font("Arial", Font.BOLD, 16));
        String cardType="";
        switch (cardName) {
            case "Ücretsiz Kart":
                cardType = "freeCardType";
                break;
            case "İndirimli Kart":
                cardType = "discountCardType";
                break;
            case "Mavi Kart":
                cardType = "blueCardType";
                break;
            case "Umumi Kart":
                cardType = "anonimCardType";
                break;
        }





        // Başvuru butonu
        JButton applyButton = new JButton("Başvuru Yap");
        String finalCardType = cardType; // Lambda içinde kullanılabilmesi için
        applyButton.addActionListener(e -> openCardEligibilityPage(finalCardType));

        // Kart paneline ekle
        cardPanel.add(cardImage, BorderLayout.CENTER);
        cardPanel.add(cardLabel, BorderLayout.NORTH);
        cardPanel.add(applyButton, BorderLayout.SOUTH);

        // Ana panele ekle
        panel.add(cardPanel);
    }

    /**
     * Kart başvurusu için kimlerin alabileceğini gösteren yeni bir pencereyi açar.
     */
    private void openCardEligibilityPage(String cardType) {
        // Yeni pencere oluşturuluyor
        JFrame eligibilityFrame = new JFrame(cardType + " - Kimler Alabilir");
        eligibilityFrame.setSize(400, 500);
        eligibilityFrame.setLayout(new GridLayout(0, 1, 10, 10));
        eligibilityFrame.setLocationRelativeTo(null);

        // Kart için uygun kullanıcıları listele
        DefaultListModel<String> listModel = new DefaultListModel<>();

        switch (cardType) {
            case "freeCardType":
                listModel.addElement("65 Yaş Üstü");
                listModel.addElement("Anne");

                break;
            case "discountCardType":
                listModel.addElement("Öğrenci");
                break;
            case "blueCardType":
                listModel.addElement("Ada Sakini");
                break;
            case "anonimCardType": // Anonim kart, herkes tarafından kullanılabilir
                listModel.addElement("Herkes");
                break;
        }

        // Pencereye listeleri yatay olarak ekle
        JPanel eligibilityPanel = new JPanel();
        eligibilityPanel.setLayout(new BoxLayout(eligibilityPanel, BoxLayout.Y_AXIS)); // Yatay sıralama için BoxLayout kullanılıyor

        for (int i = 0; i < listModel.size(); i++) {
            JPanel itemPanel = new JPanel();
            itemPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

            JLabel label = new JLabel(listModel.getElementAt(i));
            JButton applyButton = new JButton("Başvuru Yap");

            // Başvuru butonuna tıklanınca dosya yükleme ekranını aç
            applyButton.addActionListener(e -> {
                // Kullanıcı e-posta adresini UserSession üzerinden alıyoruz
                String email = UserSession.getCurrentUserEmail();

                // UserDatabase'den userId'yi alıyoruz
                UserDatabase userDatabase = new UserDatabase();
                String userId = userDatabase.getUserIdByEmail(email);

                String cardName = ""; // Lambda içinde tanımlanıyor
                switch (cardType) {
                    case "freeCardType":
                        cardName = "Ücretsiz Kart";
                        break;
                    case "discountCardType":
                        cardName = "İndirimli Kart";
                        break;
                    case "blueCardType":
                        cardName = "Mavi Kart";
                        break;
                    case "anonimCardType":
                        cardName = "Umumi Kart";
                        break;
                }



                // Kart bilgileri ile başvuru yapalım
                String cardNumber = UUID.randomUUID().toString().substring(0, 16);  // Kart numarası
                String expiryDate = LocalDate.now().plusYears(3).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")); // Geçerlilik tarihi

                CardDatabase cardDatabase=new CardDatabase();

                // CardDatabase'e kartı ekle
                cardDatabase.addCard(userId,cardName,cardType, cardNumber, expiryDate,0,false);

                openFileUploadDialog(cardType);
            });

            itemPanel.add(label);
            itemPanel.add(applyButton);

            eligibilityPanel.add(itemPanel); // itemPanel'i ana panoya ekle
        }

        // Listeleri göster
        JScrollPane scrollPane = new JScrollPane(eligibilityPanel);
        eligibilityFrame.add(scrollPane, BorderLayout.CENTER);

        // Pencereyi görünür yap
        eligibilityFrame.setVisible(true);
    }

    /**
     * Belge yükleme ekranını açar.
     */
    private void openFileUploadDialog(String cardType) {
        JFrame uploadFrame = new JFrame("Belge Yükle - " + cardType);
        uploadFrame.setSize(400, 200);
        uploadFrame.setLayout(new BorderLayout(10, 10));
        uploadFrame.setLocationRelativeTo(null);

        // Bilgilendirme etiketi
        JLabel infoLabel = new JLabel(cardType + " için gerekli belgeyi yükleyin:", SwingConstants.CENTER);

        // Dosya yükleme butonu
        JButton uploadButton = new JButton("Belge Yükle");
        uploadButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                JOptionPane.showMessageDialog(uploadFrame, "Belge Yüklendi: " + selectedFile.getName());
            }
        });

        // Panele ekle
        uploadFrame.add(infoLabel, BorderLayout.NORTH);
        uploadFrame.add(uploadButton, BorderLayout.CENTER);

        // Pencereyi görünür yap
        uploadFrame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CardApplicationPage());
    }
}
