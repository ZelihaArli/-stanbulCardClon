package UI;

import Database.ApplicationDatabase;
import Database.UserDatabase;

import javax.swing.*;
import java.awt.*;

public class ApplicationScreen {

    // Başvuru ekleme fonksiyonu
    public void addApplication(String cardType) {
        // Oturumdaki kullanıcının e-posta bilgisini alıyoruz
        String email = UserSession.getCurrentUserEmail();

        if (email != null) {
            // UserDatabase'i başlatıyoruz
            UserDatabase userDatabase = new UserDatabase();

            // E-posta ile userId alıyoruz
            String userId = userDatabase.getUserIdByEmail(email);

            if (userId != null) {
                // Başvuru işlemini başlatıyoruz
                ApplicationDatabase applicationDatabase = new ApplicationDatabase("applications.txt");
                applicationDatabase.addApplication(userId, cardType); // Başvuru ekleniyor

                // Başarılı mesajı
                JOptionPane.showMessageDialog(null, "Başvuru başarıyla eklendi.");
            } else {
                // Kullanıcı bulunamadı
                JOptionPane.showMessageDialog(null, "Geçersiz kullanıcı.");
            }
        } else {
            // Oturumda kullanıcı yoksa
            JOptionPane.showMessageDialog(null, "Lütfen giriş yapın.");
        }
    }

    // Başvuru ekranını görsel olarak oluşturma
    public void showApplicationScreen() {
        // JFrame başlatıyoruz
        JFrame frame = new JFrame("Başvuru Ekranı");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Başvuru başlığı
        JLabel titleLabel = new JLabel("Başvuru Ekranı", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        frame.add(titleLabel, BorderLayout.NORTH);

        // Kart tipi ve resmini gösterme
        JPanel cardPanel = new JPanel();
        cardPanel.setLayout(new BoxLayout(cardPanel, BoxLayout.Y_AXIS));

        JLabel cardTypeLabel = new JLabel("Kart Tipi: Blu Card");
        cardTypeLabel.setFont(new Font("Arial", Font.PLAIN, 16));

        JLabel cardImageLabel = new JLabel();
        cardImageLabel.setIcon(new ImageIcon("path_to_blu_card_image.jpg"));

        cardPanel.add(cardTypeLabel);
        cardPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        cardPanel.add(cardImageLabel);

        // Başvuru için belge yükleme
        JLabel uploadLabel = new JLabel("Başvuru için belge yükleyin:");
        JButton uploadButton = new JButton("Belge Yükle");
        uploadButton.addActionListener(e -> {
            // Belge yükleme işlemi burada yapılacak
            JOptionPane.showMessageDialog(frame, "Belge yüklendi!");
        });

        JPanel uploadPanel = new JPanel();
        uploadPanel.setLayout(new FlowLayout());
        uploadPanel.add(uploadLabel);
        uploadPanel.add(uploadButton);

        // Başvuruyu kaydetme butonu
        JButton submitButton = new JButton("Başvuruyu Gönder");
        submitButton.addActionListener(e -> {
            // Başvuru ekliyoruz
            addApplication("Blu Card"); // Örneğin Blu Card başvurusu
            frame.dispose(); // Başvuru ekranını kapat
        });

        frame.add(cardPanel, BorderLayout.CENTER);
        frame.add(uploadPanel, BorderLayout.SOUTH);
        frame.add(submitButton, BorderLayout.SOUTH);

        frame.setLocationRelativeTo(null); // Ekranı ortalayalım
        frame.setVisible(true);
    }


}
