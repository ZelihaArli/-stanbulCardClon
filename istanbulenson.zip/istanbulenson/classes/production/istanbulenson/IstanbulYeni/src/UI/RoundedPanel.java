package UI;

import javax.swing.*;
import java.awt.*;

public class RoundedPanel extends JPanel {

    private final int radius = 20; // Yuvarlak köşe yarıçapı

    public RoundedPanel() {
        super();
        setOpaque(false); // Şeffaf arka plan ayarı
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;

        // Yuvarlak kenarları daha iyi çizmek için antialiasing kullan
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Arka planı yuvarlak kenarlarla çiz
        g2.setColor(Color.WHITE); // Panelin arka plan rengini seç
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
    }
}
