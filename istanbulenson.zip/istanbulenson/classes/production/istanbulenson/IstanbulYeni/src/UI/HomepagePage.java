package UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomepagePage extends JFrame {

    public HomepagePage() {
        setTitle("Homepage");
        setSize(800, 600); // Pencere boyutunu ayarlıyoruz
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Üst panel (geri tuşu için)
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout(FlowLayout.RIGHT)); // Sağda hizalamak için FlowLayout kullanıyoruz
        JButton backButton = new JButton("Geri");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ana sayfaya geri dön
                new MainUI().setVisible(true);
                dispose();
            }
        });
        topPanel.add(backButton);

        // Başlık paneli
        JPanel titlePanel = new JPanel();
        JLabel titleLabel = new JLabel("Sevgili İstanbul, Hoşgeldiniz!", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titlePanel.add(titleLabel);

        // Kampanyaların 2x4 şeklinde yer alacağı panel
        JPanel campaignPanel = new JPanel();
        campaignPanel.setLayout(new GridLayout(4, 2, 20, 20));  // 4 satır, 2 sütun şeklinde yerleşim

        // Kampanya butonlarını ekleyelim
        JButton campaign1 = new JButton("Kampanya 1");
        JButton campaign2 = new JButton("Kampanya 2");
        JButton campaign3 = new JButton("Kampanya 3");
        JButton campaign4 = new JButton("Kampanya 4");
        JButton campaign5 = new JButton("Kampanya 5");
        JButton campaign6 = new JButton("Kampanya 6");
        JButton campaign7 = new JButton("Kampanya 7");
        JButton campaign8 = new JButton("Kampanya 8");

        // Dinamik boyutlandırma için ekranın genişliğini ve yüksekliğini kullan
        int width = getWidth();
        int height = getHeight();

        // Kampanya butonlarının boyutunu ekran boyutuna göre ayarlamak
        int buttonWidth = (width - 60) / 2; // 2 buton, aralarındaki boşluk 20 piksel
        int buttonHeight = (int) (height * 0.1); // Yüksekliği ekranın %10'u kadar ayarla

        // Butonların boyutlarını ayarla
        campaign1.setPreferredSize(new Dimension(buttonWidth, buttonHeight));
        campaign2.setPreferredSize(new Dimension(buttonWidth, buttonHeight));
        campaign3.setPreferredSize(new Dimension(buttonWidth, buttonHeight));
        campaign4.setPreferredSize(new Dimension(buttonWidth, buttonHeight));
        campaign5.setPreferredSize(new Dimension(buttonWidth, buttonHeight));
        campaign6.setPreferredSize(new Dimension(buttonWidth, buttonHeight));
        campaign7.setPreferredSize(new Dimension(buttonWidth, buttonHeight));
        campaign8.setPreferredSize(new Dimension(buttonWidth, buttonHeight));

        // Kampanya butonlarını panelin içine ekleyelim
        campaignPanel.add(campaign1);
        campaignPanel.add(campaign2);
        campaignPanel.add(campaign3);
        campaignPanel.add(campaign4);
        campaignPanel.add(campaign5);
        campaignPanel.add(campaign6);
        campaignPanel.add(campaign7);
        campaignPanel.add(campaign8);

        // Geri butonu ve kampanyalar paneli ana panelin üst kısmına ekleniyor
        add(titlePanel, BorderLayout.NORTH); // Başlık paneli
        add(topPanel, BorderLayout.NORTH); // Back tuşu
        add(campaignPanel, BorderLayout.CENTER); // Kampanyalar ortada

        // Pencereyi görünür yapalım
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new HomepagePage();  // Homepage sayfasını başlat
        });
    }
}
