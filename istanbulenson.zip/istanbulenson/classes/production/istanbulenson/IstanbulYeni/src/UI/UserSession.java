package UI;

public class UserSession {
    // Bu sınıf, oturumdaki kullanıcı bilgilerini tutar.
    private static String currentUserEmail;

    // Kullanıcının e-posta adresini saklama
    public static void setCurrentUserEmail(String email) {
        currentUserEmail = email;
    }

    // Geçerli oturumdaki kullanıcının e-posta adresini al
    public static String getCurrentUserEmail() {
        return currentUserEmail;
    }
}
