package UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Layout extends JFrame {

    private JPanel jPanelMain;
    private JLabel jLabelfirst;
    private JButton jButton1, jButton2, jButton3, jButton4, jButton5, jButton6;
    private JTextField jTextField1;
    private JPanel jPanel1, jPanel1_1, jPanel1_2, jPanel1_3, jPanel1_4, jPanel1_5;
    private JLabel jLabel1, jLabel2, jLabel3, jLabel4, jLabel5;
    private int x1, y1, x2, y2, x3, y3, x4, y4, x5, y5;

    public Layout() {
        initComponents();
    }

    private void initComponents() {
        // Ana pencere ayarları
        setTitle("Istanbul Kart");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Ortada açılmasını sağlar

        // Panel ve bileşenleri tanımlama
        jPanelMain = new JPanel();
        jPanelMain.setBackground(Color.WHITE);

        jLabelfirst = new JLabel(new ImageIcon(getClass().getResource("/UI/photos/result_download (1).jpeg")));

        jButton1 = new JButton(new ImageIcon(getClass().getResource("/UI/photos/result_homelogo.png")));
        jButton1.setBorder(null);
        jButton1.addActionListener(evt -> System.out.println("Ana Sayfa"));

        jButton2 = new JButton("Kartlarımız");
        jButton2.setFont(new Font("Segoe UI Black", Font.PLAIN, 12));
        jButton2.setForeground(Color.DARK_GRAY);
        jButton2.setBorder(null);
        jButton2.setContentAreaFilled(false);
        jButton2.addActionListener(evt -> System.out.println("Kartlarımız Butonuna Tıklandı"));

        jButton3 = new JButton("İstanbulkart Mobil");
        jButton3.setFont(new Font("Segoe UI Black", Font.PLAIN, 12));
        jButton3.setForeground(Color.DARK_GRAY);
        jButton3.setBorder(null);
        jButton3.setContentAreaFilled(false);
        jButton3.addActionListener(evt -> System.out.println("Mobil Butonuna Tıklandı"));

        jButton4 = new JButton("Kampanyalar");
        jButton4.setFont(new Font("Segoe UI Black", Font.PLAIN, 12));
        jButton4.setForeground(Color.DARK_GRAY);
        jButton4.setBorder(null);
        jButton4.setContentAreaFilled(false);
        jButton4.addActionListener(evt -> System.out.println("Kampanyalar Butonuna Tıklandı"));

        jButton5 = new JButton(new ImageIcon(getClass().getResource("/UI/photos/result_search.png")));
        jButton5.setBorder(null);
        jButton5.setContentAreaFilled(false);
        jButton5.addActionListener(evt -> System.out.println("Arama Butonuna Tıklandı"));

        jTextField1 = new JTextField();
        jTextField1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1, true));
        jTextField1.setCaretColor(Color.GRAY);
        jTextField1.setVisible(false);


        jButton6 = new JButton("Online İşlemler");
        jButton6.setFont(new Font("Segoe UI Black", Font.PLAIN, 12));
        jButton6.setForeground(Color.DARK_GRAY);
        jButton6.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1, true));
        jButton6.setContentAreaFilled(false);

        // Fare imleci el şekli
        jButton6.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Butona tıklama olayı
        jButton6.addActionListener(evt -> openNewPage());

        // Fare ile üzerine gelindiğinde renk değişikliği
        jButton6.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                jButton6.setForeground(Color.BLUE);  // Üzerine gelince renk değişir
            }

            @Override
            public void mouseExited(MouseEvent e) {
                jButton6.setForeground(Color.DARK_GRAY);  // Fare çıkınca eski renge döner
            }
        });

        // Panelde butonu ekleme
        jPanelMain.add(jButton6);
        setContentPane(jPanelMain);




























        // Alt panellerin tanımlanması
        jPanel1 = new JPanel(new CardLayout());
        jPanel1_1 = new JPanel();
        jLabel1 = new JLabel(new ImageIcon(getClass().getResource("/UI/photos/result_ist2.png")));
        jPanel1_1.add(jLabel1);
        jPanel1.add(jPanel1_1, "card2");

        // Yeni metotlar
        setCursorToHand(jButton2);
        setCursorToHand(jButton3);
        setCursorToHand(jButton4);

        // Ana paneli düzenleme
        GroupLayout layout = new GroupLayout(jPanelMain);
        jPanelMain.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(
                layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addComponent(jLabelfirst)
                                .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton1)
                                        .addComponent(jButton2)
                                        .addComponent(jButton3)
                                        .addComponent(jButton4)
                                        .addComponent(jButton5)
                                        .addComponent(jTextField1)
                                        .addComponent(jButton6))
                        )
                        .addComponent(jPanel1)
        );

        layout.setVerticalGroup(
                layout.createSequentialGroup()
                        .addComponent(jLabelfirst)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(jButton1)
                                .addComponent(jButton2)
                                .addComponent(jButton3)
                                .addComponent(jButton4)
                                .addComponent(jButton5)
                                .addComponent(jTextField1)
                                .addComponent(jButton6))
                        .addComponent(jPanel1)
        );

        setContentPane(jPanelMain);
    }

    // Yeni metotlar:
    private void setCursorToHand(JButton button) {
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void handleMouseDragged(JLabel label, MouseEvent evt, int x, int y) {
        int dx = evt.getX() - x;
        int dy = evt.getY() - y;
        label.setLocation(label.getX() + dx, label.getY() + dy);
    }

    private void resetButtonColors() {
        jButton2.setForeground(Color.BLACK);
        jButton3.setForeground(Color.BLACK);
        jButton4.setForeground(Color.BLACK);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Layout().setVisible(true);
        });
    }

    // Yeni sayfa açma metodu
    private void openNewPage() {
        // Yeni pencere oluşturma
        JFrame newFrame = new JFrame("Yeni Sayfa");
        newFrame.setSize(600, 400);
        newFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        newFrame.setLocationRelativeTo(null); // Ortada açılmasını sağlar

        // Yeni sayfada bir içerik
        JLabel label = new JLabel("Online İşlemler Sayfası", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 20));
        newFrame.add(label);

        // Yeni sayfayı göster
        newFrame.setVisible(true);
    }
}
