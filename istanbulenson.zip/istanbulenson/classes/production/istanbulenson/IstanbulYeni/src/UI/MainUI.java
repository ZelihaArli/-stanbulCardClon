package UI;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class MainUI extends JFrame {

    private final RoundedButton accountInfoButton;

    public MainUI() {
        setTitle("istanbul");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        ImageIcon icon = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");
        setIconImage(icon.getImage());

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBackground(new Color(0, 153, 204));

        JLabel textField = new JLabel("istanbul ");
        textField.setBounds(50, 5, 250, 40);
        textField.setFont(new Font("Segoe UI", Font.BOLD, 20));
        textField.setForeground(Color.white);

        JLabel kalpresmi1 = new JLabel();
        kalpresmi1.setBounds(130, 5, 250, 40);
        ImageIcon kalp = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/kalp3.jpg");
        kalpresmi1.setIcon(kalp);

        mainPanel.add(textField);
        mainPanel.add(kalpresmi1);

        JButton homepageButton = new JButton();
        homepageButton.setFont(new Font("Segoe UI", Font.BOLD, 15));
        homepageButton.setForeground(Color.white);
        homepageButton.setBackground(new Color(0, 153, 204));
        ImageIcon home = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/evim.jpg");
        homepageButton.setIcon(home);

        JButton myCardsButton = new JButton("My Cards");
        myCardsButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        myCardsButton.setForeground(Color.white);
        myCardsButton.setBackground(new Color(0, 153, 204));

        accountInfoButton = new RoundedButton("Account Info",15);
        accountInfoButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        accountInfoButton.setForeground(Color.white);
        accountInfoButton.setBackground(new Color(0, 123, 167));
        ImageIcon kisi = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/kisi.jpg");
        accountInfoButton.setIcon(kisi);

        JButton transactionsButton = new JButton("Transactions");
        transactionsButton.setForeground(Color.white);
        transactionsButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        transactionsButton.setBackground(new Color(0, 153, 204));

        JButton cardApplicationsButton = new JButton("Card Applications");
        cardApplicationsButton.setForeground(Color.white);
        cardApplicationsButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        cardApplicationsButton.setBackground(new Color(0, 153, 204));

        JButton exitButton = new JButton("Exit");
        exitButton.setForeground(Color.white);
        exitButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        exitButton.setBackground(new Color(0, 153, 204));

        Border roundBorder = BorderFactory.createLineBorder(new Color(0, 153, 204), 8);
        homepageButton.setBorder(roundBorder);
        myCardsButton.setBorder(roundBorder);
        accountInfoButton.setBorder(roundBorder);
        transactionsButton.setBorder(roundBorder);
        cardApplicationsButton.setBorder(roundBorder);
        exitButton.setBorder(roundBorder);

        homepageButton.setBounds(20, 50, 100, 50);
        myCardsButton.setBounds(140, 50, 100, 50);
        cardApplicationsButton.setBounds(260, 50, 150, 50);
        transactionsButton.setBounds(430, 50, 100, 50);
        exitButton.setBounds(550, 50, 100, 50);
        accountInfoButton.setBounds(1400, 5, 130, 45);

        JPanel resizablePanel = new JPanel();
        resizablePanel.setLayout(null);
        resizablePanel.setBackground(Color.white);
        resizablePanel.setPreferredSize(new Dimension(800, 800)); // Başlangıç boyutu

        JScrollPane scrollPane = new JScrollPane(resizablePanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBounds(0, 100, getWidth(), getHeight() - 100);

        mainPanel.add(scrollPane);

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int newWidth = getWidth() - 10; // Pencere boyutunu ayarlıyoruz (sağda biraz boşluk bırakmak için -10)
                int newHeight = getHeight() - 120; // Pencere boyutuna göre yükseklik (başlık kısmı ve scrollPanel'in üst kısmı için)

                // resizablePanel boyutunu ayarlıyoruz
                resizablePanel.setBounds(1, 100, newWidth, newHeight);
                scrollPane.setBounds(1, 100, newWidth, newHeight); // Kaydırma paneli için de aynı boyutları veriyoruz
            }
        });


        JLabel kampanya1 = new JLabel();
        kampanya1.setBounds(70, 30, 184, 320);
        ImageIcon kamp1 = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/k1.jpg");
        kampanya1.setIcon(kamp1);

        JLabel kampanya2 = new JLabel();
        kampanya2.setBounds(300, 30, 184, 320);
        ImageIcon kamp2 = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/k2.jpg");
        kampanya2.setIcon(kamp2);

        JLabel kampanya3 = new JLabel();
        kampanya3.setBounds(533, 30, 184, 320);
        ImageIcon kamp3 = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/k5.jpg");
        kampanya3.setIcon(kamp3);

        JLabel kampanya4 = new JLabel();
        kampanya4.setBounds(766, 30, 184, 320);
        ImageIcon kamp4 = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/k4.jpg");
        kampanya4.setIcon(kamp4);

        JLabel kampanya5 = new JLabel();
        kampanya5.setBounds(70, 380, 184, 320);
        ImageIcon kamp5 = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/k9.jpg");
        kampanya5.setIcon(kamp5);

        JLabel kampanya6 = new JLabel();
        kampanya6.setBounds(300, 380, 184, 320);
        ImageIcon kamp6 = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/k6.jpg");
        kampanya6.setIcon(kamp6);

        JLabel kampanya7 = new JLabel();
        kampanya7.setBounds(533, 380, 184, 320);
        ImageIcon kamp7 = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/k7.jpg");
        kampanya7.setIcon(kamp7);

        JLabel kampanya8 = new JLabel();
        kampanya8.setBounds(766, 380, 184, 320);
        ImageIcon kamp8 = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/k8.jpg");
        kampanya8.setIcon(kamp8);

        JLabel kampanya9 = new JLabel();
        kampanya9.setBounds(999, 30, 184, 320);
        ImageIcon kamp9 = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/k10.jpg");
        kampanya9.setIcon(kamp9);

        JLabel kampanya10 = new JLabel();
        kampanya10.setBounds(1232, 30, 184, 320);
        ImageIcon kamp10 = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/k15.png");
        kampanya10.setIcon(kamp10);

        JLabel kampanya11 = new JLabel();
        kampanya11.setBounds(999, 380, 184, 320);
        ImageIcon kamp11 = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/k12.jpg");
        kampanya11.setIcon(kamp11);

        JLabel kampanya12 = new JLabel();
        kampanya12.setBounds(1232, 380, 184, 320);
        ImageIcon kamp12 = new ImageIcon("C:/Users/Taha/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/k13.jpg");
        kampanya12.setIcon(kamp12);






        resizablePanel.add(kampanya1);
        resizablePanel.add(kampanya2);
        resizablePanel.add(kampanya3);
        resizablePanel.add(kampanya4);
        resizablePanel.add(kampanya5);
        resizablePanel.add(kampanya6);
        resizablePanel.add(kampanya7);
        resizablePanel.add(kampanya8);
        resizablePanel.add(kampanya9);
        resizablePanel.add(kampanya10);
        resizablePanel.add(kampanya11);
        resizablePanel.add(kampanya12);


        mainPanel.add(homepageButton);
        mainPanel.add(myCardsButton);
        mainPanel.add(accountInfoButton);
        mainPanel.add(transactionsButton);
        mainPanel.add(cardApplicationsButton);
        mainPanel.add(exitButton);
        mainPanel.add(scrollPane);
        // Butonları oluştur


        homepageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MainUI().setVisible(true); // Homepage sayfasına yönlendirme
                dispose(); // Mevcut sayfayı kapat
            }
        });

        myCardsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MyCardsPage().setVisible(true); // MyCardsPage sayfasına yönlendirme
                dispose(); // Mevcut sayfayı kapat
            }
        });

        accountInfoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AccountInfoPage().setVisible(true); // AccountInfoPage sayfasına yönlendirme
                dispose(); // Mevcut sayfayı kapat
            }
        });

        transactionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new TransactionPage().setVisible(true); // TransactionPage sayfasına yönlendirme
                dispose(); // Mevcut sayfayı kapat
            }
        });

        cardApplicationsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CardApplicationPage().setVisible(true); // CardApplicationPage sayfasına yönlendirme
                dispose(); // Mevcut sayfayı kapat
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Programı sonlandır
            }
        });



        add(mainPanel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainUI::new);
    }
}
