package UI;

import CardTypes.Cards;
import Database.CardDatabase;
import Database.UserDatabase;
import UI.UserSession;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class MyCardsPage extends JFrame {

    public MyCardsPage() {
        setTitle("My Cards");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // UserSession'dan oturumdaki e-posta adresini al
        String userEmail = UserSession.getCurrentUserEmail();
        if (userEmail == null || userEmail.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Oturum bulunamadı, lütfen giriş yapınız.", "Hata", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }

        // UserDatabase'den userId'yi al
        UserDatabase userDatabase = new UserDatabase();
        String userId = userDatabase.getUserIdByEmail(userEmail);
        if (userId == null) {
            JOptionPane.showMessageDialog(this, "Kullanıcı bulunamadı. Lütfen giriş yapınız..", "Hata", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }

        // CardDatabase'den kullanıcının kartlarını al
        CardDatabase cardDatabase = new CardDatabase();
        List<Cards> userCards = cardDatabase.getCardsByUserId(userId);

        // Kartlar için bir panel oluştur
        JPanel cardPanel = new JPanel();
        cardPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));

        if (userCards.isEmpty()) {
            cardPanel.add(new JLabel("Henüz bir karta sahip değilsiniz."));
        } else {
            for (Cards card : userCards) {
                cardPanel.add(createCardPanel(card));
            }
        }

        // Geri tuşu ekle
        JButton backButton = new JButton("Geri dön");
        backButton.addActionListener(e -> {
            dispose();
            new MainUI().setVisible(true);
        });

        JPanel backButtonPanel = new JPanel();
        backButtonPanel.add(backButton);

        add(new JScrollPane(cardPanel), BorderLayout.CENTER);
        add(backButtonPanel, BorderLayout.SOUTH);

        revalidate();
        repaint();
    }

    private JPanel createCardPanel(Cards card) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setPreferredSize(new Dimension(150, 250));

        // Kart türüne göre resim belirle
        ImageIcon cardImage = null;
        try {
            switch (card.getCardType()) {
                case "freeCardType":
                    cardImage = new ImageIcon(getClass().getResource("/UI/photos/yellowistcard.png"));
                    break;
                case "discountCardType":
                    cardImage = new ImageIcon(getClass().getResource("/UI/photos/cyanistcard.png"));
                    break;
                case "blueCardType":
                    cardImage = new ImageIcon(getClass().getResource("/UI/photos/blueistcard.png"));
                    break;
                case "anonimCardType":
                    cardImage = new ImageIcon(getClass().getResource("/UI/photos/redistcard.png"));
                    break;
                default:
                    cardImage = new ImageIcon(getClass().getResource("/UI/photos/redistcard.png"));
                    break;
            }

            if (cardImage.getImageLoadStatus() != MediaTracker.COMPLETE) {
                throw new Exception("Resim yüklenirken sorun oluştu.");
            }

            // Görüntüyü ölçekle
            Image img = cardImage.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            cardImage = new ImageIcon(img);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Resim yüklenirken bir hata oluştu: " + e.getMessage(), "Resim Hatası", JOptionPane.ERROR_MESSAGE);
        }

        // Resmi ekleyin
        JLabel cardImageLabel = new JLabel(cardImage);
        cardImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        cardImageLabel.setPreferredSize(new Dimension(100, 100));

        JLabel cardTypeLabel = new JLabel(card.getCardName(), SwingConstants.CENTER);
        cardTypeLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));

        panel.add(cardImageLabel, BorderLayout.CENTER);
        panel.add(cardTypeLabel, BorderLayout.SOUTH);

        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));

        panel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                showCardDetails(card);
            }
        });

        revalidate();
        repaint();

        return panel;
    }


    private void showCardDetails(Cards card) {
        Font customFont = new Font("Segoe UI Black", Font.BOLD, 14);

        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));

        JLabel cardTypeLabel = new JLabel("" + card.getCardName());
        cardTypeLabel.setFont(customFont);

        JLabel balanceLabel = new JLabel("Bakiye: " + card.getBalance());
        balanceLabel.setFont(customFont);

        JLabel subscriptionLabel = new JLabel("Abonman Durumu: " + (card.isSubscriptionStatus() ? "Var" : "Yok"));
        subscriptionLabel.setFont(customFont);

        detailsPanel.add(cardTypeLabel);
        detailsPanel.add(Box.createVerticalStrut(10));
        detailsPanel.add(balanceLabel);
        detailsPanel.add(Box.createVerticalStrut(10));
        detailsPanel.add(subscriptionLabel);

        JOptionPane.showMessageDialog(this, detailsPanel, "Kart Detayları", JOptionPane.INFORMATION_MESSAGE);

        detailsPanel.revalidate();
        detailsPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                new MyCardsPage().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
