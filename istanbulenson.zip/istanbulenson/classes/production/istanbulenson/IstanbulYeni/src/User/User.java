package User;

import CardTypes.Cards;
import User.Transaction;

import java.util.ArrayList;
import java.util.List;

public class User {
    private int userID;
    private String name;
    private String email;
    private String phoneNumber;
    private String password; // Şifreyi güvenli bir şekilde saklamak için hashed kullanılabilir
    private boolean isCitizen; // Kullanıcının vatandaş olup olmadığını belirtir
    private String nationalID; // TC kimlik numarası veya başka bir kimlik bilgisi
    private boolean applicationStatus; // Kart başvuru durumu
    private List<Cards> cards; // Kullanıcının sahip olduğu kartlar
    private List<Transaction> transactions; // Kullanıcının işlem geçmişi

    // Constructor
    public User(int userID, String name, String email, String phoneNumber, String password, boolean isCitizen, String nationalID) {
        this.userID = userID;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.password = password;
        this.isCitizen = isCitizen;
        this.nationalID = validateNationalID(isCitizen, nationalID);
        this.applicationStatus = false; // Varsayılan olarak başvuru durumu yok
        this.cards = new ArrayList<>();
        this.transactions = new ArrayList<>();
    }

    // Getter ve Setter Metodları
    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isCitizen() {
        return isCitizen;
    }

    public void setCitizen(boolean citizen) {
        isCitizen = citizen;
    }

    public String getNationalID() {
        return nationalID;
    }

    public void setNationalID(String nationalID) {
        this.nationalID = validateNationalID(this.isCitizen, nationalID);
    }

    public boolean getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(boolean applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public List<Cards> getCards() {
        return cards;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    // Kart ve İşlem Eklemeleri
    public void addCard(Cards card) {
        cards.add(card);
    }

    public void addTransaction(Transaction transaction) {
        transactions.add(transaction);
    }

    // Kullanıcının işlem geçmişini görüntüleme
    public void displayTransactions() {
        System.out.println("Transactions for user: " + name);
        for (Transaction t : transactions) {
            System.out.println(t.getDetails());
        }
    }


    // TC kimlik numarası doğrulama
    private String validateNationalID(boolean isCitizen, String nationalID) {
        if (isCitizen) {
            if (nationalID != null && nationalID.matches("\\d{11}")) {
                return nationalID;
            } else {
                throw new IllegalArgumentException("Invalid TC National ID for citizen.");
            }
        } else {
            return nationalID; // Vatandaş değilse farklı bir kimlik numarası kabul edilir
        }
    }
}
