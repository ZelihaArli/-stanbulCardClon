package User;

public class Transaction {
    private int transactionID;
    private double amount;
    private String transactionType; // Örn. "Biniş", "Yükleme"
    private String timestamp;

    public Transaction(int transactionID, double amount, String transactionType, String timestamp) {
        this.transactionID = transactionID;
        this.amount = amount;
        this.transactionType = transactionType;
        this.timestamp = timestamp;
    }

    public String getDetails() {
        return "ID: " + transactionID + ", Amount: " + amount + ", Type: " + transactionType + ", Date: " + timestamp;
    }
}
