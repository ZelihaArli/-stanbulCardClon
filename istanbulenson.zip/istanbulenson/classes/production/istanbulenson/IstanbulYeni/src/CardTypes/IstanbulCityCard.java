//package CardTypes;
//
//public class IstanbulCityCard extends Cards {
//    public IstanbulCityCard(int cardID) {
//        super("Istanbul City Card", 0, cardID);
//    }
//
//    @Override
//    public void applyDiscount() {
//        System.out.println("Istanbul City Card offers citywide transportation coverage.");
//    }
//}
