package CardTypes;

public class Cards {
    private String userId; // cardId yerine userId
    private String cardName;
    private String cardType;
    private String cardNumber;
    private String expiryDate;
    private double balance;
    private boolean subscriptionStatus;

    // Constructor
    public Cards(String userId, String cardName,String cardType, String cardNumber, String expiryDate, double balance, boolean subscriptionStatus) {
        this.userId = userId;
        this.cardName=cardName;
        this.cardType = cardType;
        this.cardNumber = cardNumber;
        this.expiryDate = expiryDate;
        this.balance = balance;
        this.subscriptionStatus = subscriptionStatus;
    }

    // Getter ve Setter metodları
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCardName(){
        return cardName;
    }

    public void setCardName(String cardName){
        this.cardName=cardName;
    }


    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public boolean isSubscriptionStatus() {
        return subscriptionStatus;
    }

    public void setSubscriptionStatus(boolean subscriptionStatus) {
        this.subscriptionStatus = subscriptionStatus;
    }

    // toString metodu
    @Override
    public String toString() {
        return userId
                + " " + cardName
                + " " + cardType
                + " " + cardNumber
                + " " + expiryDate
                + " " + balance
                + " " + (subscriptionStatus ? "Active" : "Inactive");
    }

}
