//package CardTypes;
//
//public class FreeCard extends Cards {
//    public FreeCard(int cardID) {
//        super("Free Card", 0, cardID);
//    }
//
//    @Override
//    public void applyDiscount() {
//        System.out.println("Free Card allows unlimited free rides.");
//    }
//}
