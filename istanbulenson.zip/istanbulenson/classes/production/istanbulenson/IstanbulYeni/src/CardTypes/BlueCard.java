//package CardTypes;
//
//public class BlueCard extends Cards {
//    public BlueCard(int cardID) {
//        super("Blue Card","Mavi Kart" ,);
//    }
//
//    @Override
//    public void applyDiscount() {
//        System.out.println("Blue Card offers unlimited rides for a fixed monthly fee.");
//    }
//}
