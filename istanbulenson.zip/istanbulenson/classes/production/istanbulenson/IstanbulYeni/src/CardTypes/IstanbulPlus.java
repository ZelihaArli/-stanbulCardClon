//package CardTypes;
//
//public class IstanbulPlus extends Cards {
//    public IstanbulPlus(int cardID) {
//        super("Istanbul Plus", 0, cardID);
//    }
//
//    @Override
//    public void applyDiscount() {
//        System.out.println("Istanbul Plus offers a 10% discount on fares.");
//    }
//}
