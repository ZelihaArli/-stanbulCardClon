//package CardTypes;
//
//public class DiscountCard extends Cards {
//    public DiscountCard(int cardID) {
//        super("Discount Card", 0, cardID);
//    }
//
//    @Override
//    public void applyDiscount() {
//        System.out.println("Discount Card offers 50% off fares for eligible passengers.");
//    }
//}
