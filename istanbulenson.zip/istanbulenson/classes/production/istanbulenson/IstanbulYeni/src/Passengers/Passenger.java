package Passengers;

import java.util.ArrayList;
import java.util.List;

public class Passenger {
    private int passengerID;
    private String name;
    private List<PassengerType> passengerTypes;

    // Constructor
    public Passenger(int passengerID, String name) {
        this.passengerID = passengerID;
        this.name = name;
        this.passengerTypes = new ArrayList<>();
    }

    // Getter ve Setter'lar
    public int getPassengerID() {
        return passengerID;
    }

    public void setPassengerID(int passengerID) {
        this.passengerID = passengerID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<PassengerType> getPassengerTypes() {
        return passengerTypes;
    }

    // Yolcu türü ekleme
    public void addPassengerType(PassengerType type) {
        if (!passengerTypes.contains(type)) {
            passengerTypes.add(type);
        }
    }

    // Yolcu türü kontrol etme
    public boolean hasPassengerType(PassengerType type) {
        return passengerTypes.contains(type);
    }

    // Yolcu türlerini listeleme
    public void displayPassengerTypes() {
        System.out.println("Passenger Types for " + name + ":");
        for (PassengerType type : passengerTypes) {
            System.out.println("- " + type);
        }
    }
}
