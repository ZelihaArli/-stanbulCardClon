package Database;

import CardTypes.Cards;

import java.io.*;
import java.util.*;

public class CardDatabase {
    private final String cardFile = "cardDatabase.txt";  // Dosya yolu burada sabitleniyor

    public CardDatabase() {
        // Dosyanın varlığını kontrol et, yoksa oluştur
        File file = new File(cardFile);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Yeni bir kart ekler (bakiye ve abonman durumu ile birlikte)
    public void addCard(String userId, String cardName,String cardType, String cardNumber, String expiryDate, double balance, boolean subscriptionStatus) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(cardFile, true))) {
            // Kart bilgilerini kullanıcı ID'si, kart tipi, kart numarası, son kullanma tarihi, bakiye ve abonman durumu ile birlikte dosyaya ekliyoruz
            String newCard = userId + "|" +cardName+"|"+ cardType + "|" + cardNumber + "|" + expiryDate + "|" + balance + "|" + subscriptionStatus;
            writer.write(newCard);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Kullanıcının sahip olduğu kartları ve ilgili bilgileri getiri
    public List<Cards> getCardsByUserId(String userId) {
        List<Cards> userCards = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(cardFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 7 && parts[0].equals(userId)) {
                    try {
                        System.out.println(line);
                        double balance = Double.parseDouble(parts[5].replace(",", "."));
                        boolean isActive = Boolean.parseBoolean(parts[5]);
                        Cards card = new Cards(parts[0], parts[1], parts[2], parts[3],parts[4], balance, isActive);
                        userCards.add(card);
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid balance format: " + parts[5]);
                    }
                } else {
                    System.err.println("Invalid data format: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return userCards;
    }


    public void updateCardBalance(String userId, String cardName,String cardNumber, double newBalance) {
        List<Cards> allCards = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(cardFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("Reading line: " + line);  // Okunan satırı göster
                String[] parts = line.split("\\|");

                if (parts.length >= 7) {  // Formatı kontrol et
                    try {
                        Cards card = new Cards(
                                parts[0], // userId
                                parts[4], // cardName
                                parts[1], // cardType
                                parts[2], // cardNumber
                                parts[3], // expiryDate
                                Double.parseDouble(parts[5].replace(",", ".")), // Bakiyeyi virgülden noktaya çevir
                                Boolean.parseBoolean(parts[6]) // isActive
                        );

                        System.out.println("Parsed card: " + card.toString());
                        System.out.println("user id: " + card.getUserId() + " vs given user id: " + userId);
                        System.out.println("card number: " + card.getCardNumber() + " vs given card number: " + cardNumber);

                        // Bakiye güncellemeyi kontrol et
                        if (card.getUserId().equals(userId) && card.getCardNumber().equals(cardNumber)) {
                            double updatedBalance = card.getBalance() + newBalance; // Eski bakiyeyi üzerine ekle
                            card.setBalance(updatedBalance); // Yeni bakiyeyi ayarla
                            System.out.println("Match found. Updating balance. New balance: " + updatedBalance);
                        }

                        allCards.add(card); // Kartı listeye ekle
                    } catch (Exception e) {
                        System.out.println("Error parsing card data: " + e.getMessage());
                    }
                } else {
                    System.out.println("Invalid card data format: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return; // Hata durumunda işlemi sonlandır
        }

        // Güncellenmiş kartları kontrol et
        System.out.println("Updated cards:");
        for (Cards card : allCards) {
            System.out.println(card.toString());
        }

        // Güncellenmiş listeyi dosyaya yazma işlemi
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(cardFile))) {
            System.out.println("Writing updated cards back to the file...");
            for (Cards card : allCards) {
                // Kartı dosyaya formatlı şekilde yaz
                writer.write(String.format("%s %s %s %s %.2f %b",
                        card.getUserId(),
                        card.getCardType(),
                        card.getCardNumber(),
                        card.getExpiryDate(),
                        card.getBalance(),
                        card.isSubscriptionStatus()
                ));
                writer.newLine();
            }
            System.out.println("Cards have been written back to the file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }











    // Kullanıcının sahip olduğu kartların bakiyesini günceller
//    public void updateCardBalance(String userId, String cardNumber, double newBalance) {
//        List<String> updatedLines = new ArrayList<>();
//        try (BufferedReader reader = new BufferedReader(new FileReader(cardFile))) {
//            String line;
//            while ((line = reader.readLine()) != null) {
//                String[] parts = line.split(" ");
//                if (parts.length > 5 && parts[0].equals(userId) && parts[2].equals(cardNumber)) {
//                    // Bakiye güncellenir
//                    parts[4] = String.valueOf(newBalance);
//                }
//                updatedLines.add(String.join(" ", parts));  // Güncellenmiş satır eklenir
//            }
//
//            // Dosyayı yeniden yaz
//            try (BufferedWriter writer = new BufferedWriter(new FileWriter(cardFile))) {
//                for (String updatedLine : updatedLines) {
//                    writer.write(updatedLine);
//                    writer.newLine(); // Yeni satır ekle
//                }
//            }
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

    // Kullanıcının sahip olduğu kartların abonman durumunu günceller

    public void updateSubscriptionStatus(String userId, String cardId, boolean newStatus) {
        List<Cards> allCards = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(cardFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 7) {
                    // Kartı oluştur
                    Cards card = new Cards(
                            parts[0], // userId
                            parts[1], // cardName
                            parts[2], // cardType
                            parts[3], // cardNumber
                            parts[4], // expiryDate
                            // Burada virgüllü sayıları nokta ile değiştiriyoruz
                            Double.parseDouble(parts[4].replace(",", ".")), // balance
                            Boolean.parseBoolean(parts[5]) // subscriptionStatus
                    );

                    // Kullanıcı ID ve kart ID'si eşleşiyorsa abonman durumu güncellenir
                    if (card.getUserId().equals(userId) && card.getCardNumber().equals(cardId)) {
                        card.setSubscriptionStatus(newStatus); // Abonman durumu güncelleniyor
                        System.out.println("Abonman durumu güncelleniyor: " + card.getCardNumber() + " " + newStatus);
                    }

                    // Güncellenmiş kartları listeye ekle
                    allCards.add(card);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return; // Hata durumunda işlemi sonlandır
        }

        // Güncellenmiş kartları dosyaya yazma işlemi
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(cardFile))) {
            for (Cards card : allCards) {
                // Kart bilgilerini dosyaya yaz
                writer.write(String.format("%s %s %s %s %.2f %b",
                        card.getUserId(),
                        card.getCardName(),
                        card.getCardType(),
                        card.getCardNumber(),
                        card.getExpiryDate(),
                        card.getBalance(),
                        card.isSubscriptionStatus()
                ));
                writer.newLine();
            }
            System.out.println("Kart bilgileri dosyaya yazıldı.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public double getBalanceForUser(String userId) {
        double balance = 0.0;
        // Burada kullanıcıya ait kartları alıp bakiyeleri toplamanız gerekebilir.
        List<Cards> userCards = getCardsByUserId(userId);
        for (Cards card : userCards) {
            balance += card.getBalance(); // Örnek, kart bakiyelerini toplar
        }
        return balance;
    }




}
