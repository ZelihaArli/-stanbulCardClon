package Database;

public class Application {
    private final String applicationId;
    private final String userId;
    private final String applicationDate;
    private final String applicationStatus;

    // Constructor
    public Application(String applicationId, String userId, String applicationDate, String applicationStatus) {
        this.applicationId = applicationId;
        this.userId = userId;
        this.applicationDate = applicationDate;
        this.applicationStatus = applicationStatus;
    }

    // Getters
    public String getApplicationId() {
        return applicationId;
    }

    public String getUserId() {
        return userId;
    }

    public String getApplicationDate() {
        return applicationDate;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }
}

