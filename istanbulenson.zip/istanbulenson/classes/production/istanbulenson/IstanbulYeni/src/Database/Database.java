package Database;

import java.io.*;
import java.util.List;

public class Database {
    private final String databaseFile = "database.txt";

    // Kullanıcı bilgilerini bir satıra kaydetme
    public void addUser(String id, String firstName, String lastName, String birthDate,
                        String phone, String email) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(databaseFile, true))) {
            // Varsayılan değerlerle yeni kullanıcıyı ekler
            String newUser = id + " " + firstName + " " + lastName + " " + birthDate + " " +
                    phone + " " + email + " 0 0 null null";
            writer.write(newUser);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Kullanıcı bilgilerini ID ile bulma
    public List<String> getUserById(String userId) {
        try (BufferedReader reader = new BufferedReader(new FileReader(databaseFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                if (parts[0].equals(userId)) {
                    return List.of(parts); // Kullanıcı bilgilerini liste olarak döndür
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null; // Kullanıcı bulunamazsa
    }

    // Kullanıcıya yeni bir kart ekleme
    public void addCardToUser(String userId, String cardId, String cardType) {
        try (BufferedReader reader = new BufferedReader(new FileReader(databaseFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter("temp.txt"))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                if (parts[0].equals(userId)) {
                    // Kart sayısını artır ve yeni kart bilgilerini ekle
                    int cardCount = Integer.parseInt(parts[6]) + 1;
                    line += " " + cardId + " " + cardType;
                    parts[6] = String.valueOf(cardCount);
                }
                writer.write(line);
                writer.newLine();
            }

            // Eski dosyayı sil ve güncellenmiş dosyayı yeniden adlandır
            new File(databaseFile).delete();
            new File("temp.txt").renameTo(new File(databaseFile));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean addApplication(String userId, String applicationId, String cardType) {
        try (BufferedReader reader = new BufferedReader(new FileReader(databaseFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter("temp.txt"))) {

            String line;
            boolean applicationAdded = false;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                if (parts[0].equals(userId)) {
                    // Kullanıcının zaten bir başvurusu varsa yeni başvuru eklenmez
                    if (!"null".equals(parts[7])) {
                        return false; // Başvuru başarısız, çünkü mevcut bir başvuru var
                    }

                    // Başvuru durumunu güncelle
                    parts[7] = applicationId;
                    parts[8] = cardType;
                    parts[6] = String.valueOf(Integer.parseInt(parts[6]) + 1); // Bekleyen başvuru sayısını artır
                    line = String.join(" ", parts);
                    applicationAdded = true;
                }
                writer.write(line);
                writer.newLine();
            }

            // Eski dosyayı sil ve temp dosyasını yeniden adlandır
            new File(databaseFile).delete();
            new File("temp.txt").renameTo(new File(databaseFile));

            return applicationAdded;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }


}
