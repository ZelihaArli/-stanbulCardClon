package Database;

import java.io.*;
import java.util.UUID;

public class ApplicationDatabase {
    private final String applicationFile;

    public ApplicationDatabase(String applicationFile) {
        this.applicationFile = applicationFile;
        File file = new File(applicationFile);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void addApplication(String userId, String cardType) {
        String applicationId = UUID.randomUUID().toString(); // Başvuru için benzersiz bir ID
        String applicationDate = java.time.LocalDate.now().toString(); // Başvuru tarihi

        // Başvuru durumu "Beklemede" olarak başlatılıyor
        String applicationStatus = "Beklemede";

        // Başvuru bilgilerini dosyaya kaydet
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(applicationFile, true))) {
            String newApplication = applicationId + " " + userId + " " + applicationDate + " " + cardType + " " + applicationStatus;
            writer.write(newApplication);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
