package Passengers;

public enum PassengerType {
        TEACHER,
        STUDENT,
        OLDER_60,
        ISLANDER,
        SUBSISTENCE,
        INSTITUTIONAL,
        MOTHER,
        VETERAN,
        COUNSELOR,
        CONSTABULARY,
        NATIONAL_SPORTSMAN,
        MARTYR_RELATIVE,
        DISABLED,
        OLDER_65,
        PRESS,
        VETERAN_RELATIVE,
        SECURITY_PERSONNEL,
        REVENUE_OFFICER,
        RANKER,
        TUIK,
        DEFAULT, ANONYMOUS
    }




