package Passengers;

import Passengers.PassengerType;
import java.util.*;

public class CardEligibilityMapping {

    private static final Map<String, List<PassengerType>> cardEligibilityMap = new HashMap<>();

    static {
        // "Ücretsiz Kart" için uygun yolcu tipleri
        cardEligibilityMap.put("freeCardType", Arrays.asList(
                PassengerType.OLDER_65,
                PassengerType.MOTHER,
                PassengerType.PRESS,
                PassengerType.CONSTABULARY,
                PassengerType.VETERAN,
                PassengerType.VETERAN_RELATIVE,
                PassengerType.SECURITY_PERSONNEL,
                PassengerType.DISABLED,
                PassengerType.RANKER,
                PassengerType.NATIONAL_SPORTSMAN,
                PassengerType.COUNSELOR,  // Muhtar
                PassengerType.MARTYR_RELATIVE,
                PassengerType.TUIK));

        // "İndirimli Kart" için uygun yolcu tipleri
        cardEligibilityMap.put("discountCardType", Arrays.asList(
                PassengerType.STUDENT,
                PassengerType.TEACHER,
                PassengerType.OLDER_60));

        // "Mavi Kart" için uygun yolcu tipleri
        cardEligibilityMap.put("blueCardType", Arrays.asList(
                PassengerType.ISLANDER,
                PassengerType.SUBSISTENCE,
                PassengerType.INSTITUTIONAL));

        // "Umumi Kart" için herkes uygun
        cardEligibilityMap.put("anonimCardType", Arrays.asList(
                PassengerType.TEACHER,
                PassengerType.STUDENT,
                PassengerType.DISABLED,
                PassengerType.OLDER_60,
                PassengerType.OLDER_65,
                PassengerType.ISLANDER,
                PassengerType.SUBSISTENCE,
                PassengerType.INSTITUTIONAL,
                PassengerType.COUNSELOR,
                PassengerType.PRESS,
                PassengerType.MARTYR_RELATIVE,
                PassengerType.REVENUE_OFFICER,
                PassengerType.ANONYMOUS));
    }

    public static List<PassengerType> getEligiblePassengerTypes(String cardType) {
        return cardEligibilityMap.getOrDefault(cardType, Collections.emptyList());
    }
}
