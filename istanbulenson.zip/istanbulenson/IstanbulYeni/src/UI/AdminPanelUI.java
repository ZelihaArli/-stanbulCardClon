package UI;

import javax.swing.*;
import java.awt.*;

public class AdminPanelUI extends JFrame {

    public AdminPanelUI() {
        setTitle("Admin Panel");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);

        ImageIcon icon = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");
        setIconImage(icon.getImage());

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        ImageIcon logo = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/result_download (1).jpeg"); // Resmin yolunu buraya yaz
        JLabel imageLabel1 = new JLabel(logo);
        imageLabel1.setBounds(20, 40, 250, 40); // Resmi yerleştirmek için konum ve boyut
       mainPanel.add(imageLabel1);
        RoundedButton applicationsButton = new RoundedButton("Başvurular",15);
        applicationsButton.setBounds(100,300,250,150);
        RoundedButton cardsButton = new RoundedButton("Kartlar",15);
        cardsButton.setBounds(400,300,250,150);

        applicationsButton.setFont(new Font("Segoe UI", Font.BOLD, 27));
        cardsButton.setFont(new Font("Segoe UI", Font.BOLD, 27));
        ImageIcon image1=new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/adminresmii.jpg");
        JLabel label1=new JLabel(image1);
        label1.setBounds(700,50,1000,700);
        mainPanel.add(label1);
        mainPanel.setBackground(new Color(255,255,255));

        mainPanel.add(applicationsButton);
        mainPanel.add(cardsButton);

        applicationsButton.addActionListener(e -> openApplicationsPage());
        cardsButton.addActionListener(e -> openCardsPage());

        add(mainPanel);
        setVisible(true);
    }

    private void openApplicationsPage() {
        new AdminApplicationsPage();
    }

    private void openCardsPage() {
        new AdminCardsPage();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminPanelUI::new);
    }
}
