package UI;

import Database.UserDatabase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TransactionPage extends JFrame {

    public TransactionPage() {
        setTitle("Transaction Page");
        setSize(700, 500);  // Sayfa boyutunu biraz küçülttüm
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(255, 255, 255));

        ImageIcon icon = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");

        setIconImage(icon.getImage());

        UserDatabase userDatabase = new UserDatabase();
        String email = UserSession.getCurrentUserEmail();
        String userId = userDatabase.getUserIdByEmail(email);

        // Başlık paneli

        JLabel titleLabel = new JLabel("İşlemler");
        titleLabel.setBounds(300,80,200,40);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));
        titleLabel.setForeground(Color.GRAY);
        add(titleLabel);
        ImageIcon logo = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/result_download (1).jpeg"); // Resmin yolunu buraya yaz
        JLabel imageLabel1 = new JLabel(logo);
        imageLabel1.setBounds(10, 10, 250, 40); // Resmi yerleştirmek için konum ve boyut
        add(imageLabel1);
        ImageIcon arka = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/arkaplanislemler.png"); // Resmin yolunu buraya yaz
        JLabel imageLabel2 = new JLabel(arka);
        imageLabel2.setBounds(900, 50, 450, 500); // Resmi yerleştirmek için konum ve boyut
        add(imageLabel2);
        // Geri butonu
        RoundedButton backButton = new RoundedButton("Geri",15);
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        backButton.setBounds(1400,10,100,40);
        backButton.setBackground(new Color(221,221,221));
        backButton.setBackground(new Color(56,60,82));
        backButton.setForeground(Color.white);
        backButton.setPreferredSize(new Dimension(100,40));

        backButton.setMinimumSize(new Dimension(100, 40));  // Min. boyut belirleyin
        backButton.setMaximumSize(new Dimension(100, 40));

        backButton.setFocusPainted(false); // Butonun etrafındaki boşluğu ayarlıyoruz
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Geri butonuna tıklandığında, önceki sayfaya dön
                new MainUI().setVisible(true);  // Önceki sayfaya geri dön
                dispose();  // Bu sayfayı kapat
            }
        });

        // Geri butonunu sağ üst köşeye yerleştirmek için
        add(backButton);  // Geri butonunu sağ üst köşeye yerleştiriyoruz


        // Kart Başvurusu butonu ekleme
        RoundedButton cardApplicationButton = new RoundedButton("Kart Başvurusu",15);
        cardApplicationButton.setBounds(300,150,250,150);
        cardApplicationButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cardApplicationButton.setBackground(new Color(221,221,221));
        ImageIcon myAppsimg = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/bakiyem.jpg");
        cardApplicationButton.setIcon(myAppsimg);
        cardApplicationButton.setHorizontalTextPosition(SwingConstants.CENTER);
        cardApplicationButton.setVerticalTextPosition(SwingConstants.BOTTOM);


        // Butona ikon ekledik
        cardApplicationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CardApplicationPage().setVisible(true);  // Kart başvurusu sayfasını aç
                dispose();  // Bu sayfayı kapat
            }
        });

        // Diğer butonları ekleyelim
        RoundedButton loadTLButton = new RoundedButton("TL Yükle",15);
        loadTLButton.setFont(new Font("Segoe UI", Font.BOLD, 14));

        loadTLButton.setBounds(600,150,250,150);
        loadTLButton.setBackground(new Color(221,221,221));
        ImageIcon loadTLimg= new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/ok.jpg");
        loadTLButton.setIcon(loadTLimg);
        loadTLButton.setHorizontalTextPosition(SwingConstants.CENTER);
        loadTLButton.setVerticalTextPosition(SwingConstants.BOTTOM);

        loadTLButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new UpdateBalancePage().setVisible(true);  // Kart başvurusu sayfasını aç
                dispose();
            }
        });

        RoundedButton subscriptionLoadButton = new RoundedButton("Abonman Yükle",15);
        subscriptionLoadButton.setFont(new Font("Segoe UI", Font.BOLD, 14));

        subscriptionLoadButton.setBounds(300,350,250,150);
        subscriptionLoadButton.setBackground(new Color(221,221,221));
        ImageIcon subsimg = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/aboman.jpg");
        subscriptionLoadButton.setIcon(subsimg);
        subscriptionLoadButton.setHorizontalTextPosition(SwingConstants.CENTER);
        subscriptionLoadButton.setVerticalTextPosition(SwingConstants.BOTTOM);


        subscriptionLoadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MonthlySubscriptionScreen().setVisible(true);
                dispose();
            }
        });


        RoundedButton myApplicationsButton = new RoundedButton("Başvurularım",15);
        myApplicationsButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        myApplicationsButton.setBounds(600,350,250,150);
        myApplicationsButton.setBackground(new Color(221,221,221));
        ImageIcon myAppsimg1 = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/bakiyem.jpg");
        myApplicationsButton.setIcon(myAppsimg1);
        myApplicationsButton.setHorizontalTextPosition(SwingConstants.CENTER);
        myApplicationsButton.setVerticalTextPosition(SwingConstants.BOTTOM);

        myApplicationsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ApplicationScreen().setVisible(true);
                dispose();
            }
        });




        // Butonları ekleyelim
        add(loadTLButton);
        add(subscriptionLoadButton);
        add(myApplicationsButton);
        add(cardApplicationButton);  // Kart başvurusu butonunu ekleyelim

        // Butonları sayfaya ekle

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ApplicationScreen appScreen = new ApplicationScreen();
            appScreen.setVisible(true);
        });
    }

}
