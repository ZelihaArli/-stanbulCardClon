package UI;

import Database.AdminDatabase;

import javax.swing.*;
import java.awt.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

    public class AdminLoginScreen extends JFrame {
        private JTextField emailField;
        private JPasswordField passwordField;
        private AdminDatabase adminDatabase; // Admin veritabanı nesnesi

        public AdminLoginScreen() {
            adminDatabase = new AdminDatabase(); // Admin veritabanını initialize et

            setTitle("Admin Panel Girişi");
            setSize(700, 500);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            getContentPane().setBackground(new Color(255, 255, 255));

            ImageIcon icon = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");
            setIconImage(icon.getImage());
            ImageIcon logo = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/result_download (1).jpeg"); // Resmin yolunu buraya yaz
            JLabel imageLabel1 = new JLabel(logo);
            imageLabel1.setBounds(10, 10, 250, 40); // Resmi yerleştirmek için konum ve boyut
            add(imageLabel1);
            JLabel customMessage = new JLabel("<html>Admin Paneline<br>Hoş Geldiniz</html>");
            customMessage.setFont(new Font("Segoe UI", Font.BOLD, 30));
            customMessage.setBounds(40, 60, 280, 140);
            add(customMessage);
            setLayout(null);

            ImageIcon icon2 = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");
            setIconImage(icon2.getImage());

            Font customFont = new Font("Segoe UI Black", Font.BOLD, 14);

            JLabel emailLabel = new JLabel("E-Posta:");
            emailLabel.setBounds(40, 220, 100, 55);

            emailLabel.setFont(customFont);
            add(emailLabel);

            emailField = new JTextField();
            emailField.setBounds(140, 230, 200, 40);
            emailField.setBorder(new RoundedBorder(7));
            emailField.setFont(customFont);
            add(emailField);

            JLabel passwordLabel = new JLabel("Şifre:");
            passwordLabel.setBounds(40, 300, 100, 55);
            passwordLabel.setFont(customFont);
            add(passwordLabel);

            passwordField = new JPasswordField();
            passwordField.setBounds(140, 300, 200, 40);
            passwordField.setBorder(new RoundedBorder(7));
            passwordField.setFont(customFont);
            add(passwordField);

            RoundedButton loginButton = new RoundedButton("Giriş",15);
            loginButton.setBounds(90, 380, 120, 40);

            loginButton.setBackground(new Color(56,60,82));
            loginButton.setForeground(Color.white);

            loginButton.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
            loginButton.setFocusPainted(false);

            loginButton.addActionListener(e -> {
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());

                if (!isValidEmail(email)) {
                    JOptionPane.showMessageDialog(AdminLoginScreen.this, "Geçersiz e-posta formatı. Lütfen geçerli bir e-posta girin.");
                    emailField.setText("");
                    passwordField.setText("");
                    return;
                }

                if (validateAdminCredentials(email, password)) {
                    JOptionPane.showMessageDialog(AdminLoginScreen.this, "Admin girişi başarılı!");
                    dispose(); // Admin giriş ekranını kapat
                    new AdminPanelUI(); // Admin paneline geçiş
                } else {
                    JOptionPane.showMessageDialog(AdminLoginScreen.this, "Eşleşme bulunamadı! Lütfen tekrar deneyin.");
                    emailField.setText("");
                    passwordField.setText("");
                }
            });
            add(loginButton);

            RoundedButton backButton = new RoundedButton("Geri",15);
            backButton.setBounds(240, 380, 120, 40);
             backButton.setBackground(new Color(56,60,82));
            backButton.setForeground(Color.white);

            backButton.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
            backButton.setFocusPainted(false);
            backButton.addActionListener(e -> {
                dispose();
                new LoginScreen(); // Normal kullanıcı giriş ekranına dönüş
            });
            add(backButton);

            ImageIcon imageIcon = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/tel2.png");
            JLabel imageLabel = new JLabel(imageIcon);
            imageLabel.setBounds(400, 40, 456, 500);
            add(imageLabel);

            ImageIcon image = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/ana2.jpeg");
            JLabel imageLa = new JLabel(image);
            imageLa.setBounds(50, 480, 1460, 700);
            add(imageLa);

            setVisible(true);
        }

        private boolean isValidEmail(String email) {
            String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
            Pattern pattern = Pattern.compile(emailRegex);
            Matcher matcher = pattern.matcher(email);

            return matcher.matches();
        }

        private boolean validateAdminCredentials(String email, String password) {
            // Veritabanı üzerinden şifreyi kontrol et
            String storedPassword = adminDatabase.getPasswordByEmail(email);
            return storedPassword != null && storedPassword.equals(password);
        }

        public static void main(String[] args) {
            SwingUtilities.invokeLater(AdminLoginScreen::new);
        }
    }

