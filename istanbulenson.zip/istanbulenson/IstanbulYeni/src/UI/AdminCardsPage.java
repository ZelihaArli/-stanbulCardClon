package UI;

import javax.swing.*;
import Database.CardDatabase;
import CardTypes.Cards;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AdminCardsPage extends JFrame{
    private JTable cardsTable;
    private DefaultTableModel cardsModel;
    private final CardDatabase cardDatabase;

    public AdminCardsPage() {
        cardDatabase = new CardDatabase();

        setTitle("Kartlar");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel cardsPanel = new JPanel(new BorderLayout());
        cardsModel = new DefaultTableModel(new String[]{"Kart ID", "Kullanıcı ID", "Kart Tipi", "Durum"}, 0);
        cardsTable = new JTable(cardsModel);
        JScrollPane cardsScrollPane = new JScrollPane(cardsTable);
        cardsPanel.add(cardsScrollPane, BorderLayout.CENTER);

        JPanel buttonsPanel = new JPanel();
        JButton viewUserCardsButton = new JButton("Kullanıcı Kartlarını Görüntüle");
        JButton deleteCardButton = new JButton("Kart Sil");
        buttonsPanel.add(viewUserCardsButton);
        buttonsPanel.add(deleteCardButton);
        cardsPanel.add(buttonsPanel, BorderLayout.SOUTH);

        viewUserCardsButton.addActionListener(e -> viewUserCards());
        deleteCardButton.addActionListener(e -> deleteSelectedCard());

        loadCardsData();

        add(cardsPanel);
        setVisible(true);
    }

    private void viewUserCards() {
        String userId = JOptionPane.showInputDialog(this, "Kullanıcı ID girin:");
        if (userId != null && !userId.isEmpty()) {
            cardsModel.setRowCount(0);
            cardDatabase.getCardsByUserId(userId).forEach(card -> {
                cardsModel.addRow(new Object[]{
                        card.getCardNumber(),
                        card.getUserId(),
                        card.getCardType(),
                        card.isSubscriptionStatus() ? "Aktif" : "Pasif"
                });
            });
        }
    }

    private void deleteSelectedCard() {
        int selectedRow = cardsTable.getSelectedRow();
        if (selectedRow != -1) {
            String cardNumber = (String) cardsModel.getValueAt(selectedRow, 0);
            String userId = (String) cardsModel.getValueAt(selectedRow, 1);
            cardDatabase.deleteCard(userId, cardNumber);
            cardsModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(this, "Seçilen kart silindi.");
        } else {
            JOptionPane.showMessageDialog(this, "Lütfen bir kart seçin.");
        }
    }

    private void loadCardsData() {
        cardsModel.setRowCount(0);
        cardDatabase.getAllCards().forEach(card -> {
            cardsModel.addRow(new Object[]{
                    card.getCardNumber(),
                    card.getUserId(),
                    card.getCardType(),
                    card.getExpiryDate()
            });
        });
    }
}


