package UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import CardTypes.Cards;
import Database.UserDatabase;
import Database.CardDatabase;

public class MonthlySubscriptionScreen extends JFrame {
    private final JComboBox<String> cardComboBox;
    private final RoundedButton loadSubscriptionButton;
    private final JLabel resultLabel;
    private final UserDatabase userDatabase = new UserDatabase();
    private final CardDatabase cardDatabase = new CardDatabase();

    private Map<String, Cards> cardMap = new HashMap<>(); // Kartları ve ID'lerini tutacak map

    public MonthlySubscriptionScreen() {
        super("Aylık Abonman Yükleme");

        // Ana pencere düzeni
        setLayout(new BorderLayout());
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        getContentPane().setBackground(new Color(255,255,255));
        ImageIcon icon = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");

        setIconImage(icon.getImage());
        // Üst panel: Geri butonu
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());
        topPanel.setBackground(new Color(255,255,255));// BorderLayout kullanıyoruz
        ImageIcon istanbullogo = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/result_download (1).jpeg"); // Resmin yolunu buraya yaz
        JLabel istlogo= new JLabel(istanbullogo);
        istlogo.setBounds(0, 0, 200, 50); // Resmi yerleştirmek için konum ve boyut
        topPanel.add(istlogo);
        //
// Geri butonu



// Abonman yükleme yazısı
        JLabel label1 = new JLabel("Abonman Yükleme", SwingConstants.CENTER);
        label1.setFont(new Font("Arial", Font.BOLD, 25));
        label1.setBackground(new Color(221, 221, 221)); // Arka plan rengi
        label1.setForeground(Color.GRAY);
        label1.setPreferredSize(new Dimension(300, 50));  // Sabit genişlik
        Box verticalBox = Box.createVerticalBox(); // Yatayda hizalamak için BoxLayout kullanıyoruz
        verticalBox.add(Box.createVerticalStrut(70));  // 20 piksel kadar boşluk ekliyoruz
        verticalBox.add(label1);  // Label'ı ekliyoruz

// Buton ve yazı stil ayarları
        JButton backButton = new RoundedButton("Geri Dön", 30);
        backButton.addActionListener(e -> {
            dispose();  // Mevcut pencereyi kapat
            new TransactionPage().setVisible(true);  // TransactionPage sayfasını aç
        });

        backButton.setBackground(new Color(56,60,82));
        backButton.setForeground(Color.white);
        backButton.setPreferredSize(new Dimension(100,40));

        backButton.setMinimumSize(new Dimension(100, 40));  // Min. boyut belirleyin
        backButton.setMaximumSize(new Dimension(100, 40));
        backButton.setBounds(1400, 10, 100, 40);
        backButton.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        backButton.setFocusPainted(false);
        backButton.setBorder(new RoundedBorder(15)); // Yuvarlak kenarlık  // Buton boyutu
        Box backBox = Box.createVerticalBox(); // Yatayda hizalamak için BoxLayout kullanıyoruz
        backBox.add(Box.createVerticalStrut(10));  // 20 piksel kadar boşluk ekliyoruz
        backBox.add(backButton);
// Geri butonunu sağa yerleştiriyoruz
        topPanel.add(backBox, BorderLayout.EAST);

// Yazıyı sola yerleştiriyoruz
        topPanel.add(verticalBox, BorderLayout.CENTER);

// Panelin üst kısmını ekleyelim
        add(topPanel, BorderLayout.NORTH);
        // Label'ı ekliyoruz




        // Merkez panel: Ana içerik
        JPanel centerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        centerPanel.setBackground(new Color(255,255,255));
        gbc.insets = new Insets(10, 10, 10, 10); // Bileşenler arasındaki boşluk

        // Kart seçimi etiketi ve combo box
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;

        JLabel label = new JLabel("Kart Seçin:");
        label.setFont(new Font("Segoe UI", Font.BOLD, 17));  // Yazı tipini değiştirebilirsiniz
        label.setPreferredSize(new Dimension(100, 30));
        label.setForeground(Color.GRAY);// Etiketin boyutunu ayarlıyoruz

// Etiketi centerPanel'e ekliyoruz
        centerPanel.add(label, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        cardComboBox = new JComboBox<>();
        cardComboBox.setPreferredSize(new Dimension(180,45));
        cardComboBox.setEnabled(false); // İlk başta pasif
        centerPanel.add(cardComboBox, gbc);

        // Kartları getir butonu
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        RoundedButton fetchCardsButton = new RoundedButton("Kartları Getir",15);
        fetchCardsButton.setBackground(new Color(221, 221, 221)); // Yeşil arka plan
        fetchCardsButton.setFont(new Font("Segoe UI", Font.BOLD, 20));
        fetchCardsButton.setForeground(Color.GRAY);
        fetchCardsButton.setPreferredSize(new Dimension(300, 70));

        fetchCardsButton.addActionListener(this::fetchCardsForCurrentUser);
        centerPanel.add(fetchCardsButton, gbc);

        // Aylık abonman yükle butonu
        gbc.gridy = 2;
        loadSubscriptionButton = new RoundedButton("Aylık Abonman Yükle",15);
        loadSubscriptionButton.setFont(new Font("Segoe UI", Font.BOLD, 17));
        loadSubscriptionButton.setBackground(new Color(221, 221, 221)); // Mavi-yeşil arka plan
        loadSubscriptionButton.setForeground(Color.GRAY);
        loadSubscriptionButton.setPreferredSize(new Dimension(300, 70));
        loadSubscriptionButton.setEnabled(false); // İlk başta pasif
        loadSubscriptionButton.addActionListener(this::loadMonthlySubscription);
        centerPanel.add(loadSubscriptionButton, gbc);

        // Sonuç etiketi
        gbc.gridy = 3;
        resultLabel = new JLabel();
        resultLabel.setHorizontalAlignment(SwingConstants.CENTER);
        centerPanel.add(resultLabel, gbc);


        add(centerPanel, BorderLayout.CENTER);
        // Sağ tarafa görsel ekleme
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BorderLayout());
        rightPanel.setBackground(new Color(255,255,255));

// Görseli yükle
        ImageIcon imageIcon = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/kartlar.jpg"); // Buraya görselin tam yolunu yazın
        JLabel imageLabel = new JLabel(imageIcon);
        imageLabel.setPreferredSize(new Dimension(600, 700)); // Görsel boyutunu ayarlayın

        rightPanel.add(imageLabel,BorderLayout.CENTER);

// Sağ paneli ana pencereye ekle
        add(rightPanel, BorderLayout.EAST);


        // Pencere ayarları
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Pencereyi ekranın ortasına yerleştirir
    }


    private void fetchCardsForCurrentUser(ActionEvent e) {
        // Geçerli kullanıcının emailinden ID'yi al
        String email = UserSession.getCurrentUserEmail();
        String userId = userDatabase.getUserIdByEmail(email);

        if (userId == null || userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Kullanıcı ID alınamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
            cardComboBox.setEnabled(false);
            loadSubscriptionButton.setEnabled(false);
            return;
        }

        // Kullanıcıya ait kartları al
        List<Cards> userCards = cardDatabase.getCardsByUserId(userId);
        if (userCards == null || userCards.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Bu kullanıcıya ait kart bulunamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
            cardComboBox.setEnabled(false);
            loadSubscriptionButton.setEnabled(false);
            return;
        }

        // Kartları combo box'a ekle
        cardComboBox.removeAllItems();
//        for (Cards card : userCards) {
//            cardComboBox.addItem(card.toString()); // Cards nesnesini doğrudan ekliyoruz
//        }
        for (Cards card : userCards) {
            // Kart numarasını daha anlaşılır şekilde gösterelim

            cardComboBox.addItem(card.getCardName()+" Kart ID: "+card.getCardNumber()+" Abonman Durumu: "+card.isSubscriptionStatus());
            cardMap.put(card.togetSubs(), card);  // String'e karşılık gelen Card nesnesini Map'e ekliyoruz
        }
        cardComboBox.setEnabled(true);
        loadSubscriptionButton.setEnabled(true);

        // Kullanıcı ID'sini abonman yükleme işlemi için sakla
        loadSubscriptionButton.putClientProperty("userId", userId);
    }


    private void loadMonthlySubscription(ActionEvent e) {
        // Seçilen kartı doğrudan Cards nesnesi olarak al
        String selectedCardString = (String) cardComboBox.getSelectedItem();
        if (selectedCardString == null) {
            JOptionPane.showMessageDialog(this, "Lütfen bir kart seçin!", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // String'den Card nesnesine ulaşmak için Map kullanıyoruz
        Cards selectedCard = cardMap.get(selectedCardString);
        if (selectedCard == null) {
            JOptionPane.showMessageDialog(this, "Seçilen kart geçersiz.", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }
        // Kart ID'sini ve kullanıcı ID'sini al
        String selectedCardId = selectedCard.getCardNumber();

        String userId = (String) loadSubscriptionButton.getClientProperty("userId");
        if (userId == null || userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Kullanıcı ID bulunamadı. Lütfen kartları tekrar getirin.", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Seçilen karta aylık abonman yükle
            cardDatabase.updateSubscriptionStatus(userId, selectedCardId, true);
            resultLabel.setText("Abonman başarıyla yüklendi: " + selectedCard.getCardNumber());
            resultLabel.setForeground(Color.GREEN);
        } catch (Exception ex) {
            ex.printStackTrace();
            resultLabel.setText("Abonman yüklenemedi: " + selectedCard.getCardNumber());
            resultLabel.setForeground(Color.RED);
        }
    }




    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // MonthlySubscriptionScreen nesnesini başlat
                MonthlySubscriptionScreen screen = new MonthlySubscriptionScreen();
                screen.setVisible(true);
            }
        });
    }
}