package UI;

import javax.swing.*;
import java.awt.*;
import java.util.List;

import CardTypes.Cards;
import Database.UserDatabase;
import Database.CardDatabase;


public class AccountInfoPage extends JFrame {
    private JLabel userIdLabel;
    private JLabel userEmailLabel;
    private JLabel accountBalanceLabel;
    private JButton backButton;
    private JButton editProfileButton;
    private JButton showCardsButton;

    private UserDatabase userDatabase = new UserDatabase();
    private CardDatabase cardDatabase = new CardDatabase();

    public AccountInfoPage() {
        super("Account Information");

        // Ana pencere düzeni
        setLayout(new BorderLayout());
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        getContentPane().setBackground(new Color(255,255,255));

        ImageIcon icon = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");
        setIconImage(icon.getImage());

        // Örnek içerik
        // Üst panel: Geri butonu
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());  // BorderLayout kullanıyoruz
        ImageIcon istanbullogo = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/result_download (1).jpeg"); // Resmin yolunu buraya yaz
        JLabel istlogo= new JLabel(istanbullogo);
        istlogo.setBounds(0, 0, 200, 50); // Resmi yerleştirmek için konum ve boyut
        topPanel.add(istlogo);
        topPanel.setBackground(new Color(255,255,255));

// Geri butonu

// Abonman yükleme yazısı
        JLabel label1 = new JLabel("Hesap Bilgilerim", SwingConstants.CENTER);
        label1.setFont(new Font("Arial", Font.BOLD, 25));
        label1.setBackground(new Color(221, 221, 221)); // Arka plan rengi
        label1.setForeground(Color.GRAY);
        label1.setPreferredSize(new Dimension(200, 50));  // Sabit genişlik
        Box verticalBox = Box.createVerticalBox(); // Yatayda hizalamak için BoxLayout kullanıyoruz
        verticalBox.add(Box.createVerticalStrut(50));  // 20 piksel kadar boşluk ekliyoruz
        verticalBox.add(label1);  // Label'ı ekliyoruz

// Buton ve yazı stil ayarları


        backButton = new RoundedButton("Geri Dön", 10);
        backButton.addActionListener(e -> {
            dispose();  // Mevcut pencereyi kapat
            new MainUI().setVisible(true);  // TransactionPage sayfasını aç
        });

        backButton.setBackground(new Color(56,60,82));
        backButton.setForeground(Color.white);

        backButton.setPreferredSize(new Dimension(100,40));

        backButton.setMinimumSize(new Dimension(100, 40));  // Min. boyut belirleyin
        backButton.setMaximumSize(new Dimension(100, 40));
        backButton.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        backButton.setFocusPainted(false);
          // Buton boyutu
        Box backBox = Box.createVerticalBox(); // Yatayda hizalamak için BoxLayout kullanıyoruz
        backBox.add(Box.createVerticalStrut(10));  // 20 piksel kadar boşluk ekliyoruz
        backBox.add(backButton);
// Geri butonunu sağa yerleştiriyoruz
        topPanel.add(backBox, BorderLayout.EAST);

// Yazıyı sola yerleştiriyoruz
        topPanel.add(verticalBox, BorderLayout.CENTER);

// Panelin üst kısmını ekleyelim
        add(topPanel, BorderLayout.NORTH);
        // Label'ı ekliyoruz

        // Merkez panel: Hesap bilgilerini gösteren alan
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(new Color(255,255,255));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Bileşenler arasındaki boşluk

        // Kullanıcı ID etiketi ve değeri
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;

        JLabel label = new JLabel("Kullanıcı ID");
        label.setFont(new Font("Arial", Font.BOLD, 20));
        label.setBackground(new Color(221, 221, 221)); // Arka plan rengi
        label.setForeground(Color.GRAY);
        label.setPreferredSize(new Dimension(300, 50));  //
        centerPanel.add(label, gbc);

        gbc.gridx = 1;

        gbc.anchor = GridBagConstraints.WEST;
        userIdLabel = new JLabel();
        userIdLabel.setFont(new Font("Arial", Font.BOLD, 20));
        userIdLabel.setBackground(new Color(221, 221, 221)); // Arka plan rengi
        userIdLabel.setForeground(Color.GRAY);
        userIdLabel.setPreferredSize(new Dimension(200, 50));  //

        centerPanel.add(userIdLabel, gbc);

        // Kullanıcı e-posta etiketi ve değeri
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        JLabel label2 = new JLabel("E-posta");
        label2.setFont(new Font("Arial", Font.BOLD, 20));
        label2.setBackground(new Color(221, 221, 221)); // Arka plan rengi
        label2.setForeground(Color.GRAY);
        label2.setPreferredSize(new Dimension(300, 50));
        centerPanel.add(label2, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        userEmailLabel = new JLabel();
        userEmailLabel.setFont(new Font("Arial", Font.BOLD, 20));
        userEmailLabel.setBackground(new Color(221, 221, 221)); // Arka plan rengi
        userEmailLabel.setForeground(Color.GRAY);
        userEmailLabel.setPreferredSize(new Dimension(300, 50));
        centerPanel.add(userEmailLabel, gbc);

        // Hesap bakiyesi etiketi ve değeri
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.EAST;
        JLabel label3 = new JLabel("Hesap Bakiyesi");
        label3.setFont(new Font("Arial", Font.BOLD, 20));
        label3.setBackground(new Color(221, 221, 221)); // Arka plan rengi
        label3.setForeground(Color.GRAY);
        label3.setPreferredSize(new Dimension(300, 50));
        centerPanel.add(label3, gbc);


        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        accountBalanceLabel = new JLabel();
        accountBalanceLabel.setFont(new Font("Arial", Font.BOLD, 20));
        accountBalanceLabel.setBackground(new Color(221, 221, 221)); // Arka plan rengi
        accountBalanceLabel.setForeground(Color.GRAY);
        accountBalanceLabel.setPreferredSize(new Dimension(300, 50));
        centerPanel.add(accountBalanceLabel, gbc);

        // Kartları göster butonu
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        showCardsButton = new JButton("Kartları Göster");
        showCardsButton.setFont(new Font("Arial", Font.BOLD, 20));
        showCardsButton.setBackground(new Color(221, 221, 221)); // Arka plan rengi
        showCardsButton.setForeground(Color.GRAY);
        showCardsButton.setPreferredSize(new Dimension(300, 50));
        showCardsButton.addActionListener(e -> showCards());
        centerPanel.add(showCardsButton, gbc);

        /*// Profil düzenle butonu
        gbc.gridy = 4;
        editProfileButton = new JButton("Profili Düzenle");
        editProfileButton.setFont(new Font("Arial", Font.BOLD, 20));
        editProfileButton.setBackground(new Color(221, 221, 221)); // Arka plan rengi
        editProfileButton.setForeground(Color.GRAY);
        editProfileButton.setPreferredSize(new Dimension(300, 50));
        editProfileButton.addActionListener(e -> {
            // EditProfilePage sınıfından bir nesne oluştur ve görünür yap
            SwingUtilities.invokeLater(() -> {
                new EditProfilePage(new UserDatabase()).setVisible(true); // UserDatabase aktarımı
            });
            this.dispose(); // Mevcut pencereyi kapat
        });

        centerPanel.add(editProfileButton, gbc);*/
        JPanel rightPanel = new JPanel();
        rightPanel.setPreferredSize(new Dimension(600,100));// Profil düzenleme sayfasına yönlendir

        rightPanel.setBackground(new Color(255, 255, 255));



        // Resim ekleme
        ImageIcon imageIcon = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/ist.jpg");
        Image image = imageIcon.getImage().getScaledInstance(700, 500, Image.SCALE_SMOOTH); // Boyutlandır
        JLabel imageLabel = new JLabel(new ImageIcon(image));
        rightPanel.add(imageLabel);

        // Merkez ve sağ paneli birleştir
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(rightPanel, BorderLayout.EAST);

        add(mainPanel, BorderLayout.CENTER);


        // Merkez paneli ekle


        // Pencere ayarları
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Pencereyi ekranın ortasına yerleştirir

        // Kullanıcı bilgilerini yükle
        loadAccountInfo();
    }

    // Hesap bilgilerini yükleyen metot
    private void loadAccountInfo() {
        // Kullanıcı ID'sini ve e-posta adresini UserSession üzerinden alıyoruz
        String email = UserSession.getCurrentUserEmail();
        String userId = userDatabase.getUserIdByEmail(email);
        System.out.println("user id: "+userId);

        if (userId != null && !userId.isEmpty()) {
            userIdLabel.setText(userId);
            userEmailLabel.setText(email);

            // Hesap bakiyesini al
            double balance = cardDatabase.getBalanceForUser(userId); // CardDatabase'deki geçerli metodu çağırıyoruz
            accountBalanceLabel.setText(String.format("%.2f", balance));
        } else {
            JOptionPane.showMessageDialog(this, "Kullanıcı bilgileri alınamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Kartları gösterme işlemi
    private void showCards() {
        String userId = userIdLabel.getText();
        if (userId == null || userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Geçerli kullanıcı bulunamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Kartları göstermek için CardDatabase'ten kartları al
        List<Cards> userCards = cardDatabase.getCardsByUserId(userId);
        if (userCards != null && !userCards.isEmpty()) {
            StringBuilder cardList = new StringBuilder("Kullanıcıya ait kartlar:\n");
            for (Cards card : userCards) {
                cardList.append(card.toString()).append("\n");
            }
            JOptionPane.showMessageDialog(this, cardList.toString(), "Kullanıcı Kartları", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Bu kullanıcıya ait kart bulunamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Profili düzenleme işlemi
    private void editProfile() {
        String userId = userIdLabel.getText();
        if (userId == null || userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Geçerli kullanıcı bulunamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }


    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // AccountInfoPage nesnesini başlat
            AccountInfoPage page = new AccountInfoPage();
            page.setVisible(true);
        });
    }
}