
package UI;

import Database.UserDatabase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditProfilePage extends JFrame {
    private UserDatabase userDatabase;

    // GUI bileşenleri
    private JTextField emailField, newValueField;
    private JPasswordField passwordField;
    private JComboBox<String> fieldComboBox;
    private JButton updateButton;

    public EditProfilePage(UserDatabase userDatabase) {
        this.userDatabase = userDatabase;

        setTitle("Profil Bilgilerini Düzenle");
        setSize(400, 300);
        setLayout(new GridLayout(6, 2, 10, 10));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Bileşenleri oluştur
        JLabel emailLabel = new JLabel("E-posta:");
        emailField = new JTextField();

        JLabel passwordLabel = new JLabel("Şifre:");
        passwordField = new JPasswordField();

        JLabel fieldLabel = new JLabel("Değiştirmek istediğiniz bilgi:");
        String[] fields = {"E-posta", "Şifre"};
        fieldComboBox = new JComboBox<>(fields);

        JLabel newValueLabel = new JLabel("Yeni Değer:");
        newValueField = new JTextField();

        updateButton = new JButton("Güncelle");

        // Bileşenleri pencereye ekle
        add(emailLabel);
        add(emailField);

        add(passwordLabel);
        add(passwordField);

        add(fieldLabel);
        add(fieldComboBox);

        add(newValueLabel);
        add(newValueField);

        add(new JLabel()); // Boş alan
        add(updateButton);

        // Buton olayını tanımla
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleUpdate();
            }
        });

        setVisible(true);
    }

    private void handleUpdate() {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());
        String fieldToUpdate = (String) fieldComboBox.getSelectedItem();
        String newValue = newValueField.getText();

        if (email.isEmpty() || password.isEmpty() || newValue.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tüm alanları doldurduğunuzdan emin olun.", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // E-posta ile kullanıcı ID'si alınır
        String userId = userDatabase.getUserIdByEmail(email);
        if (userId != null) {
            // Kullanıcı ID'si bulunmuşsa, güncelleme işlemi yapılır
            boolean success = userDatabase.updateFieldByEmail(email, fieldToUpdate.toLowerCase(), newValue);
            if (success) {
                JOptionPane.showMessageDialog(this, "Profil başarıyla güncellendi!", "Başarılı", JOptionPane.INFORMATION_MESSAGE);
                dispose();  // Pencereyi kapat
            } else {
                JOptionPane.showMessageDialog(this, "Güncelleme sırasında bir hata oluştu.", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "E-posta adresi bulunamadı.", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Ana method
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            UserDatabase db = new UserDatabase();
            new EditProfilePage(db);
        });
    }
}
