package UI;
import Database.ApplicationDatabase;
import Database.CardDatabase;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AdminApplicationsPage extends JFrame {
    private JTable applicationsTable;
    private DefaultTableModel applicationsModel;
    private final ApplicationDatabase applicationDatabase;

    public AdminApplicationsPage() {
        applicationDatabase = new ApplicationDatabase();

        setTitle("Başvurular");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel applicationsPanel = new JPanel(new BorderLayout());

        // Tabloya yeni sütunlar ekliyoruz
        applicationsModel = new DefaultTableModel(new String[]{
                "Başvuru ID", "Kullanıcı ID", "Durum", "Belge", "Kart Tipi", "Passenger Type", "Başvuru Tarihi"
        }, 0);
        applicationsTable = new JTable(applicationsModel);
        JScrollPane applicationsScrollPane = new JScrollPane(applicationsTable);
        applicationsPanel.add(applicationsScrollPane, BorderLayout.CENTER);

        JPanel buttonsPanel = new JPanel();
        JButton approveButton = new JButton("Onayla");
        JButton declineButton = new JButton("Reddet");
        buttonsPanel.add(approveButton);
        buttonsPanel.add(declineButton);
        applicationsPanel.add(buttonsPanel, BorderLayout.SOUTH);

        approveButton.addActionListener(e -> handleApplicationUpdate("Onaylandı"));
        declineButton.addActionListener(e -> handleApplicationUpdate("Reddedildi"));

        loadApplicationsData();

        add(applicationsPanel);
        setVisible(true);
    }

    private void handleApplicationUpdate(String status) {
        int selectedRow = applicationsTable.getSelectedRow();
        if (selectedRow != -1) {
            String applicationId = (String) applicationsModel.getValueAt(selectedRow, 0);
            applicationDatabase.updateApplicationStatus(applicationId, status);
            applicationsModel.setValueAt(status, selectedRow, 2);
            JOptionPane.showMessageDialog(this, "Başvuru durumu güncellendi: " + status);

            if (status.equals("Onaylandı")) {
                String userId = (String) applicationsModel.getValueAt(selectedRow, 1);  // Kullanıcı ID
                String cardType = (String) applicationsModel.getValueAt(selectedRow, 4);  // Kart Tipi
                String applicationDate = (String) applicationsModel.getValueAt(selectedRow, 6);  // Başvuru Tarihi
                CardDatabase cardDatabase=new CardDatabase();

                // Kullanıcıya ait daha önce kart var mı kontrol et
                if (!cardDatabase.isCardExists(userId,cardType)) {
                    // Kart yoksa, yeni kart oluştur

                    // Kart tipine göre kart adı eşleştirme
                    String cardName = getCardNameByType(cardType);  // Kart tipi ile ad eşleştirmesi
                    // CardDatabase'e kartı ekle
                    cardDatabase.addCard(userId, cardName, cardType);

                    JOptionPane.showMessageDialog(this, "Kart başarıyla eklendi.");
                } else {
                    JOptionPane.showMessageDialog(this, "Bu kullanıcı için zaten bir kart var.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Lütfen bir başvuru seçin.");
        }
    }

    // Kart tipi ile eşleşen kart adını döndüren metod
    private String getCardNameByType(String cardType) {
        switch (cardType) {
            case "discountCardType":
                return "İndirimli Kart";
            case "freeCardType":
                return "Ücretsiz Kart";
            case "blueCardType":
                return "Mavi Kart";
            case "anonymousCardType":
                return "Umumi Kart";
            default:
                return "Umumi Kart";  // Varsayılan kart adı
        }
    }

    // Benzersiz kart numarası oluşturma fonksiyonu


    private void loadApplicationsData() {
        applicationsModel.setRowCount(0);  // Tabloyu temizliyoruz

        // ApplicationDatabase'den verileri alıyoruz
        applicationDatabase.getAllApplications().forEach(app -> {
            // Başvurudan alınan verileri ve yeni verileri tabloya ekliyoruz
            applicationsModel.addRow(new Object[]{
                    app.getApplicationId(),               // Başvuru ID
                    app.getUserId(),                      // Kullanıcı ID
                    app.getApplicationStatus(),           // Durum
                    app.getDocument(),                    // Belge
                    app.getCardType(),                    // Kart Tipi (Başvurudan alınıyor)
                    app.getPassengerType(),               // Passenger Type (Başvurudan alınıyor)
                    app.getApplicationDate()              // Başvuru Tarihi (Başvurudan alınıyor)
            });
        });
    }
}
