package UI;

import Database.ApplicationDatabase;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ApplicationScreen extends JFrame {

    private JTable applicationTable;
    private DefaultTableModel tableModel;

    public ApplicationScreen() {
        // Başlık ve pencere boyut ayarları
        setTitle("Mevcut Başvurular");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        ImageIcon icon = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");

        setIconImage(icon.getImage());

        // Başvuru başlığı
        JLabel titleLabel = new JLabel("Başvurularım", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        add(titleLabel, BorderLayout.NORTH);

        // Tabloyu ve modelini oluşturma
        String[] columnNames = {"Başvuru ID", "Kullanıcı ID", "Başvuru Tarihi", "Kart Tipi", "Durum"};
        tableModel = new DefaultTableModel(columnNames, 0);
        applicationTable = new JTable(tableModel);

        // Tabloyu kaydırma paneline ekleme
        JScrollPane scrollPane = new JScrollPane(applicationTable);
        add(scrollPane, BorderLayout.CENTER);

        // Başvuruları yükleme
        loadApplications();

        // Geri butonunu ekleme
        setupBackButton();

        // Ekranı ortala
        setLocationRelativeTo(null);
    }

    private void loadApplications() {
        ApplicationDatabase applicationDatabase = new ApplicationDatabase();
        List<Application> applications = applicationDatabase.getAllApplications();

        if (applications.isEmpty()) {
            System.out.println("Başvuru verisi bulunamadı.");
            JOptionPane.showMessageDialog(this, "Başvuru verisi bulunamadı.", "Hata", JOptionPane.ERROR_MESSAGE);
        } else {
            System.out.println("Başvurular başarıyla yüklendi.");
        }

        // Her başvuru için tabloya satır ekliyoruz
        for (Application application : applications) {
            tableModel.addRow(new Object[]{
                    application.getApplicationId(),
                    application.getUserId(),
                    application.getApplicationDate(),
                    application.getCardType(),
                    application.getApplicationStatus()
            });
        }

        // Tabloyu güncelle
        tableModel.fireTableDataChanged();  // Tabloyu yenilemek için
    }


    private void updateApplicationStatus(String applicationId, String newStatus) {
        ApplicationDatabase applicationDatabase = new ApplicationDatabase();
        applicationDatabase.updateApplicationStatus(applicationId, newStatus);
        JOptionPane.showMessageDialog(this, "Başvuru durumu güncellendi.");

        // Tabloyu güncelle
        tableModel.setRowCount(0); // Eski verileri temizle
        loadApplications(); // Yeni verileri yükle
    }

    private void setupBackButton() {
        // Geri butonunu oluştur
        JButton backButton = new JButton("Geri");
        backButton.setFont(new Font("Arial", Font.PLAIN, 18));
        backButton.setBackground(Color.LIGHT_GRAY);

        // Geri butonuna tıklama işlemi
        backButton.addActionListener(e -> {
            // Geri butonuna tıklandığında açılacak ekranı belirle
            dispose();  // ApplicationScreen'i kapat
            new TransactionPage().setVisible(true);  // OpeningScreen'i aç
        });

        // Panel oluşturup geri butonunu yerleştir
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(backButton);

        // Butonu en alt kısma ekle
        add(buttonPanel, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        ApplicationScreen appScreen = new ApplicationScreen();
        appScreen.setVisible(true);
    }
}
