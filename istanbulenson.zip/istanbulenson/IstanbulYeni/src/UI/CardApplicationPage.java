package UI;

import Database.ApplicationDatabase;
import Database.UserDatabase;
import Passengers.CardEligibilityMapping;
import Passengers.PassengerType;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.List;

public class CardApplicationPage extends JFrame {

    public CardApplicationPage() {
        setTitle("Card Application");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);

        ImageIcon icon = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");
        setIconImage(icon.getImage());

        // Ana panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Başlık paneli
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BorderLayout());

        // Başlık ekleme
        JLabel titleLabel = new JLabel("Kart Başvurusu", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));

        // Alt başlık ekleme
        JLabel subtitleLabel = new JLabel("Hangi karta başvurmak istersin?", SwingConstants.CENTER);
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 16));

        // Geri butonu
        RoundedButton backButton = new RoundedButton("Geri",15);
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        backButton.setBounds(1400,10,100,40);
        backButton.setBackground(new Color(221,221,221));
        backButton.setBackground(new Color(56,60,82));
        backButton.setForeground(Color.white);
        backButton.setPreferredSize(new Dimension(100,40));

        backButton.setMinimumSize(new Dimension(100, 40));  // Min. boyut belirleyin
        backButton.setMaximumSize(new Dimension(100, 40));

        backButton.setFocusPainted(false);
        backButton.addActionListener(e -> {
            new MainUI().setVisible(true);
            dispose();
        });

        // Başlıkları ve butonu titlePanel'e ekleme
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.add(titleLabel);
        textPanel.add(subtitleLabel);

        titlePanel.add(textPanel, BorderLayout.CENTER);
        titlePanel.add(backButton, BorderLayout.EAST);

        // Kart butonlarını resim ve isimle birlikte ekleme
        JPanel cardPanel = new JPanel();
        cardPanel.setLayout(new BoxLayout(cardPanel, BoxLayout.Y_AXIS));
        addCardOption(cardPanel, "Ücretsiz Kart", "C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/yesil.png");
        addCardOption(cardPanel, "İndirimli Kart", "C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/mavi.jpg");
        addCardOption(cardPanel, "Mavi Kart", "C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/goldmavi.jpeg");
        addCardOption(cardPanel, "Umumi Kart", "C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/kirmizi.png");

        // Başlık paneli ve geri butonu panelini ana panele ekle
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(cardPanel, BorderLayout.CENTER);

        // Ana paneli pencereye ekle
        add(mainPanel);
        setVisible(true);
    }

    private void addCardOption(JPanel panel, String cardName, String imagePath) {
        JPanel cardPanel = new JPanel();
        cardPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 15, 15));
        cardPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        cardPanel.setPreferredSize(new Dimension(200, 100));

        // Kart resmi
        JLabel cardImage = new JLabel();
        ImageIcon imageIcon = new ImageIcon(imagePath);
        Image scaledImage = imageIcon.getImage().getScaledInstance(70, 100, Image.SCALE_SMOOTH);
        cardImage.setIcon(new ImageIcon(scaledImage));
        cardImage.setPreferredSize(new Dimension(70, 100));

        // Kart ismi
        JLabel cardLabel = new JLabel(cardName);
        cardLabel.setFont(new Font("Arial", Font.BOLD, 16));
        cardLabel.setHorizontalAlignment(SwingConstants.LEFT);
        cardLabel.setVerticalAlignment(SwingConstants.CENTER);

        String cardType = switch (cardName) {
            case "Ücretsiz Kart" -> "freeCardType";
            case "İndirimli Kart" -> "discountCardType";
            case "Mavi Kart" -> "blueCardType";
            case "Umumi Kart" -> "anonimCardType";
            default -> "unknown";
        };

        cardPanel.add(cardImage);
        cardPanel.add(cardLabel);
        cardPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                openCardEligibilityPage(cardType);
            }
        });

        panel.add(cardPanel);
    }

    private void openCardEligibilityPage(String cardType) {
        JFrame eligibilityFrame = new JFrame(cardType + " - Kimler Alabilir");
        eligibilityFrame.setSize(400, 500);
        eligibilityFrame.setLocationRelativeTo(null);

        // PassengerType'ları saklamak için bir list model oluşturuyoruz
        DefaultListModel<String> listModel = new DefaultListModel<>();

        // CardEligibilityMapping sınıfından uygun yolcu türlerini alıyoruz
        List<PassengerType> eligibleTypes = CardEligibilityMapping.getEligiblePassengerTypes(cardType);

        // Eğer uygun yolcu türleri boşsa, bir hata mesajı gösterelim
        if (eligibleTypes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Bu kart için uygun yolcu türü bulunamadı.", "Hata", JOptionPane.ERROR_MESSAGE);
            return;  // Eğer uygun tür yoksa, işlemden çıkıyoruz
        }

        // Uygun türleri list modeline ekliyoruz
        for (PassengerType type : eligibleTypes) {
            listModel.addElement(type.name());  // Enum'un string değerini alıyoruz
            System.out.println("Uygun Tür: " + type.name());  // Debug için
        }

        // JList oluşturuyoruz
        JList<String> list = new JList<>(listModel);

        // List'i kaydırılabilir yapmak için JScrollPane ekliyoruz
        JScrollPane scrollPane = new JScrollPane(list);

        // Uygunluk panelini oluşturuyoruz
        JPanel eligibilityPanel = new JPanel();
        eligibilityPanel.setLayout(new BoxLayout(eligibilityPanel, BoxLayout.Y_AXIS));

        // List modelindeki her bir öğe için başvuru butonu ekliyoruz
        for (int i = 0; i < listModel.size(); i++) {
            JPanel itemPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JLabel label = new JLabel(listModel.getElementAt(i));

            RoundedButton applyButton = new RoundedButton("Başvuru Yap",15);
            applyButton.setBackground(new Color(221,221,221));

            int finalI = i;  // Lambda içinde kullanılabilmesi için finalI olarak tanımlıyoruz
            applyButton.addActionListener(e -> {
                String email = UserSession.getCurrentUserEmail();
                UserDatabase userDatabase = new UserDatabase();
                String userId = userDatabase.getUserIdByEmail(email);

                // ListModel'deki seçilen yolcu türünü alıyoruz
                String passengerTypeName = listModel.getElementAt(finalI);
                PassengerType passengerType = PassengerType.valueOf(passengerTypeName);  // Enum değeri alıyoruz

                System.out.println("Başvuru Yapılıyor: " + passengerTypeName);  // Debug için

                // Dosya yükleme ekranını açıyoruz
                openFileUploadDialog(userId, cardType, passengerType);  // Doğru parametreyi gönderiyoruz
            });

            itemPanel.add(label);
            itemPanel.add(applyButton);  // Burada butonun doğru şekilde eklenmesi gerektiğini unutmayın.
            eligibilityPanel.add(itemPanel);  // Paneli uygunluk paneline ekliyoruz
        }

        // Scroll pane'i uygunluk paneline ekliyoruz
        eligibilityFrame.add(eligibilityPanel, BorderLayout.CENTER);  // Sonrasında paneli alt kısma ekliyoruz

        eligibilityFrame.setVisible(true);
    }

    private void openFileUploadDialog(String userId, String cardType, PassengerType passengerType) {
        System.out.println("openFileUploadDialog metodu çağrıldı!");  // Debugging için

        JFrame uploadFrame = new JFrame("Belge Yükle - " + cardType);
        uploadFrame.setSize(700, 500);
        uploadFrame.setLayout(new BorderLayout(10, 10));
        uploadFrame.setLocationRelativeTo(null);

        // Paneli yeniden düzenleyelim
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));  // Dikey kutu düzeni

        // Bilgi etiketi
        JLabel infoLabel = new JLabel(cardType + " için gerekli belgeyi yükleyin:", SwingConstants.CENTER);
        panel.add(infoLabel);

        // Başvuru yap butonu
        RoundedButton uploadButton = new RoundedButton("Belge Yükle",15);
        uploadButton.setBackground(new Color(221,221,221));
        uploadButton.setAlignmentX(Component.CENTER_ALIGNMENT);  // Butonu yatayda ortalayalım
        uploadButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showOpenDialog(null);

            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();

                if (selectedFile != null && selectedFile.exists()) {
                    try {
                        // Dosya yükleme işlemi
                        File destinationDir = new File("C:/Users/adema/Desktop/Projeler/");
                        if (!destinationDir.exists()) {
                            destinationDir.mkdirs();  // Eğer klasör yoksa, oluşturuyoruz
                        }

                        // Dosyayı hedef dizine kopyalıyoruz
                        File destination = new File(destinationDir, selectedFile.getName());
                        Files.copy(selectedFile.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);

                        // Başarı mesajı
                        JOptionPane.showMessageDialog(uploadFrame, "Belge başarıyla yüklendi: " + selectedFile.getName());

                        // Başvuru bilgilerini kaydediyoruz
                        ApplicationDatabase applicationDatabase = new ApplicationDatabase();
                        applicationDatabase.addApplication(userId, cardType, "waiting", passengerType, selectedFile.getName());  // Belge adını geçiyoruz

                        // Başarı mesajı
                        JOptionPane.showMessageDialog(uploadFrame, "Başvurunuz başarıyla oluşturuldu.");
                        uploadFrame.dispose(); // Dosya yükleme ekranını kapatıyoruz

                    } catch (IOException ioException) {
                        // Hata durumunda mesaj gösteriyoruz
                        ioException.printStackTrace();
                        JOptionPane.showMessageDialog(uploadFrame, "Belge yükleme sırasında bir hata oluştu.", "Hata", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(uploadFrame, "Geçersiz dosya seçildi.", "Hata", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        panel.add(uploadButton);  // Butonu panele ekliyoruz

        uploadFrame.add(panel, BorderLayout.CENTER);  // Paneli frame'e ekliyoruz
        uploadFrame.setVisible(true);  // Dosya yükleme ekranını görünür yapıyoruz
    }




    public static void main(String[] args) {
        SwingUtilities.invokeLater(CardApplicationPage::new);
    }
}
