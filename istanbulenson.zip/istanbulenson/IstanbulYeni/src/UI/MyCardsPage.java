package UI;

import CardTypes.Cards;
import Database.CardDatabase;
import Database.UserDatabase;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.InputStream;
import java.util.List;

public class MyCardsPage extends JFrame {

    public MyCardsPage() {
        setTitle("My Cards");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        ImageIcon icon = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");

        setIconImage(icon.getImage());

        // Kullanıcının oturumunu doğrula
        String userEmail = UserSession.getCurrentUserEmail();
        if (userEmail == null || userEmail.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Oturum bulunamadı, lütfen giriş yapınız.", "Hata", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }

        UserDatabase userDatabase = new UserDatabase();
        String userId = userDatabase.getUserIdByEmail(userEmail);

        if (userId == null) {
            JOptionPane.showMessageDialog(this, "Kullanıcı bulunamadı. Lütfen giriş yapınız.", "Hata", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }

        // Kartları çek
        CardDatabase cardDatabase = new CardDatabase();
        List<Cards> userCards = cardDatabase.getCardsByUserId(userId);

        JPanel cardPanel = new JPanel();
        cardPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));

        if (userCards.isEmpty()) {
            cardPanel.add(new JLabel("Henüz bir karta sahip değilsiniz."));
        } else {
            for (Cards card : userCards) {
                cardPanel.add(createCardPanel(card));
            }
        }

        // İstanbul logosunu yükle
        ImageIcon istanbullogo = loadImageIcon("/UI/photos/result_download (1).jpeg");
        JLabel istlogo = new JLabel(istanbullogo);
        istlogo.setPreferredSize(new Dimension(200, 50));

        // Geri dön butonu
        RoundedButton backButton = new RoundedButton("Geri dön", 15);
        backButton.setBackground(new Color(56, 60, 82));
        backButton.setForeground(Color.white);
        backButton.setPreferredSize(new Dimension(100, 40));
        backButton.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        backButton.setFocusPainted(false);
        backButton.addActionListener(e -> {
            dispose();
            new MainUI().setVisible(true);
        });

        // Geri dön butonunu ve logoyu içeren üst panel
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(istlogo, BorderLayout.WEST); // Logoyu sol tarafa yerleştir
        topPanel.add(backButton, BorderLayout.EAST); // Butonu sağ tarafa yerleştir
        add(topPanel, BorderLayout.NORTH);

        add(new JScrollPane(cardPanel), BorderLayout.CENTER);

        revalidate();
        repaint();
    }

    private JPanel createCardPanel(Cards card) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setPreferredSize(new Dimension(150, 250));

        ImageIcon cardImage = null;
        try {
            // Resim yükleme
            switch (card.getCardType()) {
                case "freeCardType":
                    cardImage = loadImageIcon("/UI/photos/kirmizi.png");
                    break;
                case "discountCardType":
                    cardImage = loadImageIcon("/UI/photos/yesil.png");
                    break;
                case "blueCardType":
                    cardImage = loadImageIcon("/UI/photos/goldmavi.jpeg");
                    break;
                case "anonimCardType":
                    cardImage = loadImageIcon("/UI/photos/mavi.jpg");
                    break;
                default:
                    cardImage = loadImageIcon("/UI/photos/default.png");
                    break;
            }

            // Resmi ölçeklendir
            Image img = cardImage.getImage().getScaledInstance(150, 250, Image.SCALE_SMOOTH);
            cardImage = new ImageIcon(img);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Resim yüklenirken bir hata oluştu: " + e.getMessage(), "Resim Hatası", JOptionPane.ERROR_MESSAGE);
        }

        JLabel cardImageLabel = new JLabel(cardImage);
        cardImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        JLabel cardTypeLabel = new JLabel(card.getCardName(), SwingConstants.CENTER);

        panel.add(cardImageLabel, BorderLayout.CENTER);
        panel.add(cardTypeLabel, BorderLayout.SOUTH);
        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));

        ImageIcon finalCardImage = cardImage;
        panel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new CardDetailsPage(card.getCardNumber(), card.getBalance(), finalCardImage, card.isSubscriptionStatus()).setVisible(true);
            }
        });

        return panel;
    }

    private ImageIcon loadImageIcon(String path) {
        try {
            InputStream stream = getClass().getResourceAsStream(path);
            if (stream == null) {
                throw new Exception("Resim dosyası bulunamadı: " + path);
            }
            Image image = ImageIO.read(stream);
            return new ImageIcon(image);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Resim yüklenemedi: " + path, "Resim Hatası", JOptionPane.ERROR_MESSAGE);
            return new ImageIcon(); // Varsayılan veya boş bir simge döndür
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                new MyCardsPage().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
