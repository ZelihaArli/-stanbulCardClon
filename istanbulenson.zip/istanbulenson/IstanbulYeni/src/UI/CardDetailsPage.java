package UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CardDetailsPage extends JFrame {

    public CardDetailsPage(String cardId, double balance, ImageIcon cardImage, boolean subscriptionStatus) {
        setTitle("Kart Detayları");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(135, 206, 250));
        topPanel.setPreferredSize(new Dimension(600, 200));
        JLabel cardImageLabel = new JLabel();
        cardImageLabel.setIcon(cardImage);
        cardImageLabel.setPreferredSize(new Dimension(100, 100));
        topPanel.add(cardImageLabel);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel cardIdLabel = new JLabel("Kart ID: " + cardId);
        JLabel balanceLabel = new JLabel("Bakiye: " + balance);
        JLabel subscriptionLabel = new JLabel("Abonman Durumu: " + (subscriptionStatus ? "Var" : "Yok"));

        JButton loadBalanceButton = new JButton("TL Yükle");
        JButton subscriptionLoadButton = new JButton("Abonman Yükle");

        loadBalanceButton.addActionListener(e -> new UpdateBalancePage().setVisible(true));
        subscriptionLoadButton.addActionListener(e -> new MonthlySubscriptionScreen().setVisible(true));

        gbc.gridx = 0;
        gbc.gridy = 0;
        bottomPanel.add(cardIdLabel, gbc);
        gbc.gridy = 1;
        bottomPanel.add(balanceLabel, gbc);
        gbc.gridy = 2;
        bottomPanel.add(subscriptionLabel, gbc);
        gbc.gridy = 3;
        bottomPanel.add(loadBalanceButton, gbc);
        gbc.gridy = 4;
        bottomPanel.add(subscriptionLoadButton, gbc);

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(bottomPanel, BorderLayout.CENTER);

        add(mainPanel);
    }
}
