package UI;

import Passengers.PassengerType;


public class Application {
    private final String applicationId;
    private final String userId;
    private final String applicationDate;
    private final String cardType;
    private final String applicationStatus;
    private final PassengerType passengerType;
    private final String document;  // Başvuru belgesi (dosya yolu ya da belge adı)

    public Application(String applicationId, String userId, String applicationDate, String cardType,
                       String applicationStatus, PassengerType passengerType, String document) {
        this.applicationId = applicationId;
        this.userId = userId;
        this.applicationDate = applicationDate;
        this.cardType = cardType;
        this.applicationStatus = applicationStatus;
        this.passengerType = passengerType;
        this.document = document;  // Yeni parametre
    }

    // Getters
    public String getApplicationId() {
        return applicationId;
    }

    public String getUserId() {
        return userId;
    }

    public String getApplicationDate() {
        return applicationDate;
    }

    public String getCardType() {
        return cardType;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public PassengerType getPassengerType() {
        return passengerType;
    }

    public String getDocument() {
        return document;  // Yüklenen belgeyi döndüren getter
    }

    @Override
    public String toString() {
        return applicationId + " " + userId + " " + passengerType + " " + cardType + " " +
                applicationDate + " " + applicationStatus + " " + document;  // Belgeyi de göster
    }
}
