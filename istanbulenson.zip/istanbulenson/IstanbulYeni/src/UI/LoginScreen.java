package UI;

import Database.UserDatabase;

import javax.swing.*;
import java.awt.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginScreen extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;
    private UserDatabase userDatabase; // UserDatabase nesnesi

    public LoginScreen() {
        userDatabase = new UserDatabase(); // Veritabanını initialize et (dosya yolu kullanıcıya göre değişebilir)

        setTitle("istanbul");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        getContentPane().setBackground(new Color(255, 255, 255));
        JLabel customMessage = new JLabel("<html>Şehri doya doya<br>yaşadığın kart,<br>İstanbulkart</html>");
        customMessage.setFont(new Font("Segoe UI", Font.BOLD, 30)); // Yazı tipi ayarı
        customMessage.setBounds(40, 60, 280, 140); // Mesajın konumu ve boyutu
        add(customMessage); // Mesajı pencereye ekle
        // Düzen yöneticisini devre dışı bırak
        setLayout(null);
        ImageIcon icon = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");

        setIconImage(icon.getImage());

        // Font ayarları
        Font customFont = new Font("Segoe UI Black", Font.BOLD, 14); // Font ayarı


        JLabel emailLabel = new JLabel("E-Posta:");
        emailLabel.setBounds(40, 220, 100, 55); // Sabit boyut ve konum
        emailLabel.setFont(customFont); // Fontu uygula
        add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(140, 230, 200, 40); // Sabit boyut ve konum
        emailField.setFont(customFont); // Fontu uygula
        emailField.setBorder(new RoundedBorder(7));
        add(emailField);

        JLabel passwordLabel = new JLabel("Şifre:");
        passwordLabel.setBounds(40, 300, 100, 55); // Sabit boyut ve konum
        passwordLabel.setFont(customFont); // Fontu uygula
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(140, 300, 200, 40); // Sabit boyut ve konum
        passwordField.setBorder(new RoundedBorder(7));
        passwordField.setFont(customFont); // Fontu uygula
        add(passwordField);

        // Login butonu
        RoundedButton loginButton = new RoundedButton("Giriş",20);
        loginButton.setBounds(90, 380, 120, 40); // Yüksekliği artırdık
        loginButton.setBackground(new Color(56,60,82));
        loginButton.setForeground(Color.white);
        loginButton.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        loginButton.setFocusPainted(false);
        // Fontu uygula
        loginButton.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            if (!isValidEmail(email)) {
                JOptionPane.showMessageDialog(LoginScreen.this, "Geçersiz e-posta formatı. Lütfen geçerli bir e-posta girin.");
                emailField.setText(""); // E-posta alanını temizle
                passwordField.setText(""); // Şifreyi temizle
                return; // E-posta geçerli değilse işlemi sonlandır
            }

            // E-posta formatı doğruysa, şifreyi doğrula
            if (validateCredentials(email, password)) {
                JOptionPane.showMessageDialog(LoginScreen.this, "Giriş yapıldı.");
                UserSession.setCurrentUserEmail(email); // Oturuma e-posta kaydedildi.
                dispose(); // Giriş ekranını kapat
                new MainUI(); // Ana ekrana geçiş
            } else {
                JOptionPane.showMessageDialog(LoginScreen.this, "Eşleşme bulunamadı! Lütfen tekrar deneyin.");
                emailField.setText(""); // E-posta alanını temizle
                passwordField.setText(""); // Şifreyi temizle
            }
        });
        add(loginButton);

        // Yeni Kayıt butonu
        RoundedButton registerButton = new RoundedButton("Yeni Kayıt",20);
        registerButton.setBounds(240, 380, 120, 40); // Yüksekliği artırdık
        registerButton.setBackground(new Color(56,60,82));
        registerButton.setForeground(Color.white);

        registerButton.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        registerButton.setFocusPainted(false);

        registerButton.addActionListener(e -> {
            RegisterScreen registerScreen = new RegisterScreen(); // Yeni kayıt ekranını başlat
            registerScreen.setVisible(true); // Yeni kayıt ekranını görünür yap
            dispose(); // Login ekranını kapat
        });
        add(registerButton);


        RoundedButton adminLoginButton = new RoundedButton("Admin Girişi",20);
        adminLoginButton.setBounds(150, 430, 200, 40);
        adminLoginButton.setBackground(new Color(56,60,82));
        adminLoginButton.setForeground(Color.white);


        adminLoginButton.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        adminLoginButton.setFocusPainted(false);
        adminLoginButton.addActionListener(e -> {
            dispose();
            new AdminLoginScreen(); // Admin giriş ekranını başlat
        });
        add(adminLoginButton);

        ImageIcon logo = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/result_download (1).jpeg"); // Resmin yolunu buraya yaz
        JLabel imageLabel1 = new JLabel(logo);
        imageLabel1.setBounds(10, 10, 250, 40); // Resmi yerleştirmek için konum ve boyut
        add(imageLabel1);
        // Resim dosyasını yüklemek ve JLabel'a eklemek
        ImageIcon imageIcon = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/tel2.png"); // Resmin yolunu buraya yaz
        JLabel imageLabel = new JLabel(imageIcon);
        imageLabel.setBounds(400, 40, 456, 500); // Resmi yerleştirmek için konum ve boyut
        add(imageLabel);
        ImageIcon image = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/ana2.jpeg"); // Resmin yolunu buraya yaz
        JLabel imageLa = new JLabel(image);
        imageLa.setBounds(50, 480, 1460, 700); // Resmi yerleştirmek için konum ve boyut
        add(imageLa);



        setVisible(true);
    }

    // E-posta formatı doğrulama
    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);

        return matcher.matches(); // E-posta geçerli mi?
    }


    // E-posta ve şifre doğrulama
    private boolean validateCredentials(String email, String password) {
        // Veritabanı üzerinden şifreyi al
        String storedPassword = userDatabase.getPasswordByEmail(email);

        // Eğer şifre eşleşiyorsa giriş başarılı
        return storedPassword != null && storedPassword.equals(password);
    }




    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginScreen::new); // Giriş ekranını başlat
    }
}
