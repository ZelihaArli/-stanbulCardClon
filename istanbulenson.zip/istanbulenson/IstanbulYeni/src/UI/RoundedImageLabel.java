package UI;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class RoundedImageLabel extends JComponent {
    private Image image;
    private int borderRadius;

    public RoundedImageLabel(Image image, int borderRadius) {
        this.image = image;
        this.borderRadius = borderRadius;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Hafif oval bir çerçeve oluştur
        int arcWidth = borderRadius * 2;  // Yatayda daha az kavis
        int arcHeight = borderRadius;    // Dikeyde daha fazla kavis
        Shape clip = new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), arcWidth, arcHeight);
        g2.setClip(clip);

        // Görüntüyü çiz
        g2.drawImage(image, 0, 0, getWidth(), getHeight(), this);

        // Çerçeve çizmek isterseniz
        g2.setClip(null);
        g2.setColor(Color.white);
        g2.setStroke(new BasicStroke(3)); // Çerçeve genişliği
        g2.draw(clip);
    }
}
