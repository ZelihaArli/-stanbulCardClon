
package UI;

import CardTypes.Cards;
import Database.CardDatabase;
import Database.UserDatabase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UpdateBalancePage extends JFrame {

    private final CardDatabase cardDatabase;
    private Map<String, Cards> cardMap = new HashMap<String, Cards>();

    public UpdateBalancePage() {
        setTitle("Update Card Balance");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(255, 255, 255));
        ImageIcon icon = new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg");
        setIconImage(icon.getImage());

        // Layout manager'ı kaldırıyoruz
        setLayout(null);

        // CardDatabase nesnesi
        cardDatabase = new CardDatabase();


        UserDatabase userDatabase = new UserDatabase();
        String email = UserSession.getCurrentUserEmail();
        String userId = userDatabase.getUserIdByEmail(email);

        // Kullanıcının sahip olduğu kartlar
        List<Cards> userCards = cardDatabase.getCardsByUserId(userId);
        JLabel header=new JLabel("Bakiye Yükleme");
        header.setFont(new Font("Segoe UI", Font.BOLD, 25));
        header.setBounds(500,200,200,40);
        add(header);

        ImageIcon myBalance =new ImageIcon("C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/bakiyeee.png");
        JLabel BalanceImg=new JLabel(myBalance);
        BalanceImg.setFont(new Font("Segoe UI", Font.BOLD, 25));
        BalanceImg.setBounds(1100,280,260,180);
        add(BalanceImg);
        ImageIcon logo = new ImageIcon("C:/Users/adema/Desktop/istanbulenson/IstanbulYeni/src/UI/photos/result_download (1).jpeg"); // Resmin yolunu buraya yaz
        JLabel imageLabel1 = new JLabel(logo);
        imageLabel1.setBounds(10, 10, 250, 40); // Resmi yerleştirmek için konum ve boyut
        add(imageLabel1);

        // Kart seçimi
        JLabel cardLabel = new JLabel("Güncellenecek kartı seçin:");
        cardLabel.setBounds(500, 300, 250, 30);
        cardLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));// x, y, width, height
        add(cardLabel);

        JComboBox<String> cardComboBox = new JComboBox<>();
        cardComboBox.setBounds(700, 300, 250, 40);
        cardComboBox.setBackground(new Color(255,255,255));
        cardComboBox.setBorder(new RoundedBorder(7));
        for (Cards card : userCards) {
            cardComboBox.addItem(card.togetBalance());
            cardMap.put(card.togetBalance(),card);
        }
        add(cardComboBox);

        // Bakiye seçimi
        JLabel balanceLabel = new JLabel("Yüklenecek bakiyeyi seçin:");
        balanceLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        balanceLabel.setBounds(500, 360, 250, 30);
        add(balanceLabel);

        JComboBox<String> balanceComboBox = new JComboBox<>(new String[]{"10 TL", "50 TL", "100 TL", "200 TL", "500 TL"});
        balanceComboBox.setBounds(700, 360, 250, 40);
        balanceComboBox.setBorder(new RoundedBorder(7));
        balanceComboBox.setBackground(new Color(255,255,255));
        add(balanceComboBox);

        // Özel bakiye girişi
        JLabel customBalanceLabel = new JLabel("Veya özel bir bakiye girin:");
        customBalanceLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        customBalanceLabel.setBounds(500, 420, 250, 30);
        add(customBalanceLabel);

        JTextField customBalanceField = new JTextField();
        customBalanceField.setBounds(700, 420, 250, 40);
        customBalanceField.setBorder(new RoundedBorder(7));
        add(customBalanceField);

        // Update butonu
        RoundedButton updateButton = new RoundedButton("Bakiye Güncelle",15);
        updateButton.setBounds(800, 500, 150, 40);
        updateButton.setBackground(new Color(56,60,82));
        updateButton.setForeground(Color.white);

        updateButton.setFont(new Font("Segoe UI Black", Font.BOLD, 12));
        updateButton.setFocusPainted(false);

        add(updateButton);

        // Geri butonu
        RoundedButton backButton = new RoundedButton("Geri",15);
        backButton.setBackground(new Color(56,60,82));
        backButton.setForeground(Color.white);

        backButton.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
        backButton.setFocusPainted(false);

        backButton.setBounds(1300, 20, 140, 40);

        add(backButton);

        // Update butonu için işlem
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedCardString = (String) cardComboBox.getSelectedItem();
                if (selectedCardString == null || !selectedCardString.contains(" ")) {
                    JOptionPane.showMessageDialog(UpdateBalancePage.this,
                            "Invalid card format. Please select a valid card.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Cards selectedCard = cardMap.get(selectedCardString);
                if (selectedCard == null) {
                    JOptionPane.showMessageDialog(UpdateBalancePage.this,
                            "Error retrieving card details.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;}

                String cardNumber=selectedCard.getCardNumber();
                String cardName=selectedCard.getCardName();


                double newBalance = 0;

                String selectedBalance = (String) balanceComboBox.getSelectedItem();
                if (selectedBalance != null) {
                    switch (selectedBalance) {
                        case "10 TL":
                            newBalance = 10;
                            break;
                        case "50 TL":
                            newBalance = 50;
                            break;
                        case "100 TL":
                            newBalance = 100;
                            break;
                        case "200 TL":
                            newBalance = 200;
                            break;
                        case "500 TL":
                            newBalance = 500;
                            break;
                    }
                }

                if (!customBalanceField.getText().isEmpty()) {
                    try {
                        newBalance = Double.parseDouble(customBalanceField.getText());

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(UpdateBalancePage.this,
                                "Invalid amount. Please enter a valid number.",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                try {
                    cardDatabase.updateCardBalance(userId, cardName,cardNumber, newBalance);
                    JOptionPane.showMessageDialog(UpdateBalancePage.this,
                            "Balance updated successfully!",
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                    customBalanceField.setText("");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(UpdateBalancePage.this,
                            "An error occurred while updating the balance. Please try again.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Geri butonu işlemi
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new TransactionPage().setVisible(true);
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new UpdateBalancePage();
            }
        });
    }
}
