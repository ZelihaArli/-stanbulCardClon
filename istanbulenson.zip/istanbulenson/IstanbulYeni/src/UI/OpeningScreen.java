package UI;

import javax.swing.*;
import java.awt.*;

public class OpeningScreen extends JFrame {

    private static final int SCREEN_WIDTH = 700;
    private static final int SCREEN_HEIGHT = 500;
    private static final String WINDOW_TITLE = "Istanbul";
    private static final String BACKGROUND_IMAGE_PATH = "C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbulkart-taksim.jpg";
    private static final String ICON_IMAGE_PATH = "C:/Users/adema/Desktop/Istanbulenson/IstanbulYeni/src/UI/photos/istanbullogo.jpeg";
    private static final int DELAY_MS = 3000;

    private boolean isLoginScreenOpened = false;

    public OpeningScreen() {
        initializeWindow();
        setupBackgroundPanel();
        setupWindowIcon();
        startLoginScreenTimer();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }

    private void initializeWindow() {
        setTitle(WINDOW_TITLE);
        setSize(SCREEN_WIDTH, SCREEN_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void setupBackgroundPanel() {
        BackgroundPanel backgroundPanel = new BackgroundPanel(BACKGROUND_IMAGE_PATH);
        backgroundPanel.setLayout(new BorderLayout());
        add(backgroundPanel);
    }

    private void setupWindowIcon() {
        try {
            ImageIcon icon = new ImageIcon(ICON_IMAGE_PATH);
            setIconImage(icon.getImage());
        } catch (Exception e) {
            System.err.println("Error loading window icon: " + ICON_IMAGE_PATH);
            e.printStackTrace();
        }
    }

    private void startLoginScreenTimer() {
        new Timer(DELAY_MS, e -> openLoginScreen()).start();
    }

    private void openLoginScreen() {
        if (!isLoginScreenOpened) {
            isLoginScreenOpened = true;
            new LoginScreen().setVisible(true);
            dispose();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(OpeningScreen::new);
    }
}

class BackgroundPanel extends JPanel {
    private final Image backgroundImage;

    public BackgroundPanel(String imagePath) {
        this.backgroundImage = loadBackgroundImage(imagePath);
    }

    private Image loadBackgroundImage(String imagePath) {
        try {
            Image image = new ImageIcon(imagePath).getImage();
            if (image == null) {
                throw new IllegalArgumentException("Background image could not be loaded!");
            }
            return image;
        } catch (Exception e) {
            System.err.println("Error loading background image: " + imagePath);
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
