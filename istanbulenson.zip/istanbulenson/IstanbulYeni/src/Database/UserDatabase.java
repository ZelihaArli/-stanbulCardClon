package Database;

import java.io.*;
import java.util.*;
import java.util.UUID;

public class UserDatabase {
    private final String userFile = "userDatabase.txt";  // Dosya yolu burada sabitleniyor

    public UserDatabase() {
        // Dosyanın varlığını kontrol et, yoksa oluştur
        File file = new File(userFile);
        if (!file.exists()) {
            try {
                file.createNewFile();  // Dosya yoksa oluşturulacak
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Yeni kullanıcı ekler
    public void addUser(String tcidno, String name, String surname, String birthdate, String phone, String email, String password) {
        // UUID oluşturuluyor ve benzersiz bir userid olarak ayarlanıyor
        String userid = UUID.randomUUID().toString();  // Rastgele UUID oluştur

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(userFile, true))) {
            // Kullanıcı verisini dosyaya kaydet
            String newUser = userid + " " + tcidno + " " + name + " " + surname + " " + birthdate + " " + phone + " " + email + " " + password;
            writer.write(newUser);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // E-posta ile şifreyi almak için yeni fonksiyon
    public String getPasswordByEmail(String email) {
        try (BufferedReader reader = new BufferedReader(new FileReader(userFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Kullanıcı bilgilerini al ve e-posta ile karşılaştır
                String[] userFields = line.split(" ");
                if (userFields.length > 7 && userFields[6].equals(email)) {
                    return userFields[7]; // E-posta bulunduysa, şifreyi döndür
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null; // Eğer e-posta bulunamazsa, null döndür
    }

    // Kullanıcıyı doğrular
    public boolean validateLogin(String userId, String password) {
        List<String> userLine = findLineById(userFile, userId);  // Kullanıcıyı bul
        if (userLine != null && userLine.size() > 7) {
            String storedPassword = userLine.get(7);  // Şifre dosyadan alınır
            return storedPassword.equals(password);  // Şifreyi doğrula
        }
        return false;  // Kullanıcı bulunamazsa ya da şifre uyuşmazsa
    }

    // Kart sayısını artırır
    public void incrementCardCount(String userId) {
        updateField(userFile, userId, 7, value -> String.valueOf(Integer.parseInt(value) + 1));
    }

    // Başvuru sayısını artırır
    public void incrementApplicationCount(String userId) {
        updateField(userFile, userId, 8, value -> String.valueOf(Integer.parseInt(value) + 1));
    }

    // Kullanıcıyı id'ye göre bulur
    private List<String> findLineById(String filePath, String userid) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Kullanıcı ID'sini kontrol et, userid'ye göre bulma yap
                if (line.startsWith(userid + " ")) {
                    return List.of(line.split(" "));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;  // Eğer kullanıcı bulunamazsa null döner
    }

    // Dosyadaki bir alanı günceller
    private void updateField(String filePath, String userid, int fieldIndex, FieldUpdater updater) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath));
             BufferedWriter writer = new BufferedWriter(new FileWriter("temp.txt"))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                if (parts[0].equals(userid)) {
                    parts[fieldIndex] = updater.update(parts[fieldIndex]);
                    line = String.join(" ", parts);
                }
                writer.write(line);
                writer.newLine();
            }

            // Eski dosyayı sil ve yeni dosyayı yeniden adlandır
            new File(filePath).delete();
            new File("temp.txt").renameTo(new File(filePath));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public boolean updateFieldByEmail(String email, String fieldToUpdate, String newValue) {
        File inputFile = new File(userFile);  // Orijinal dosya
        File tempFile = new File("temp.txt");  // Geçici dosya
        boolean isUpdated = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String currentLine;
            while ((currentLine = reader.readLine()) != null) {
                String[] userFields = currentLine.split(" ");

                // Eğer e-posta eşleşirse, güncelleme işlemi yapılır
                if (userFields.length > 7 && userFields[6].equals(email)) {
                    if ("email".equalsIgnoreCase(fieldToUpdate)) {
                        userFields[6] = newValue;  // E-posta alanı güncellenir
                    } else if ("password".equalsIgnoreCase(fieldToUpdate)) {
                        userFields[7] = newValue;  // Şifre alanı güncellenir
                    }
                    isUpdated = true;
                }

                // Güncellenmiş satır temp dosyasına yazılır
                writer.write(String.join(" ", userFields));
                writer.newLine();
            }

            writer.flush();  // Verilerin tam olarak yazıldığından emin olun
            writer.close();  // Yazma işlemi bittikten sonra writer'ı kapatın

            // Yedekleme işlemi
            if (inputFile.exists()) {
                File backupFile = new File(userFile + ".bak");
                // Orijinal dosya yedeklenir
                if (inputFile.renameTo(backupFile)) {
                    // Temp dosyasını orijinal dosya olarak yeniden adlandır
                    if (tempFile.renameTo(inputFile)) {
                        // Orijinal dosya silinir
                        backupFile.delete();  // Yedek dosya silinir
                        System.out.println("Güncelleme başarılı.");
                    } else {
                        // Eğer temp dosyası orijinal dosya olarak adlandırılamazsa, yedek dosya geri yüklenir
                        backupFile.renameTo(inputFile);
                        System.out.println("Temp dosyası orijinal dosya olarak adlandırılamadı, yedek geri yüklendi.");
                    }
                } else {
                    System.out.println("Yedek dosya alınamadı.");
                    return false;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        return isUpdated;
    }


    // E-posta ile kullanıcı ID'sini bulur
    public String getUserIdByEmail(String email) {
        try (BufferedReader reader = new BufferedReader(new FileReader(userFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Kullanıcı bilgilerini al ve e-posta ile karşılaştır
                String[] userFields = line.split(" ");
                if (userFields.length > 7 && userFields[6].equals(email)) {
                    return userFields[0]; // E-posta bulunduysa, userId (ilk alan) döner
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null; // Eğer e-posta bulunamazsa, null döner
    }

    // UserId'ye göre kullanıcı bilgilerini döndürür
    public List<String> getUserById(String userId) {
        return findLineById(userFile, userId);
    }

    // FieldUpdater arayüzü burada tanımlanacak
    @FunctionalInterface
    private interface FieldUpdater {
        String update(String currentValue);  // Mevcut değeri alır ve güncellenmiş değeri döndürür
    }
}
