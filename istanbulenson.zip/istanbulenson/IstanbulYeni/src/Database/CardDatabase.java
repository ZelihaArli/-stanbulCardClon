package Database;

import CardTypes.Cards;

import java.io.*;
import java.util.*;

public class CardDatabase {
    private final String cardFile = "cardDatabase.txt";  // Dosya yolu burada sabitleniyor

    public CardDatabase() {
        // Dosyanın varlığını kontrol et, yoksa oluştur
        File file = new File(cardFile);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Yeni bir kart ekler (bakiye ve abonman durumu ile birlikte)
    public void addCard(String userId, String cardName, String cardType) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(cardFile, true))) {
            // Kart numarasını benzersiz bir UUID ile oluşturuyoruz
            String cardNumber = generateUniqueCardNumber();

            // Son kullanma tarihi varsayılan olarak 1 yıl sonrası olarak atanabilir
            String expiryDate = getDefaultExpiryDate();

            // Bakiye ve abonelik durumu varsayılan olarak belirleniyor
            double balance = 0.0;
            boolean subscriptionStatus = false;

            // Kart bilgilerini dosyaya yazıyoruz
            String newCard = userId + "|" + cardName + "|" + cardType + "|" + cardNumber + "|" + expiryDate + "|" + balance + "|" + subscriptionStatus;
            writer.write(newCard);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Benzersiz kart numarası oluşturma fonksiyonu
    private String generateUniqueCardNumber() {
        return java.util.UUID.randomUUID().toString().substring(0, 16); // İlk 8 karakteri alıyoruz
        }



    // Varsayılan son kullanma tarihi fonksiyonu (1 yıl sonrası)
    private String getDefaultExpiryDate() {
        java.time.LocalDate expiryDate = java.time.LocalDate.now().plusYears(3); // 3 yıl sonrası
        return expiryDate.toString();
    }


    // Kullanıcının sahip olduğu kartları ve ilgili bilgileri getiri
    public List<Cards> getCardsByUserId(String userId) {
        List<Cards> userCards = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(cardFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 7 && parts[0].equals(userId)) {
                    try {
                        System.out.println(line);
                        double balance = Double.parseDouble(parts[5].replace(",", "."));
                        boolean isActive = Boolean.parseBoolean(parts[6]);
                        Cards card = new Cards(parts[0], parts[1], parts[2], parts[3],parts[4], balance, isActive);
                        userCards.add(card);
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid balance format: " + parts[5]);
                    }
                } else {
                    System.err.println("Invalid data format: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return userCards;
    }


    public List<Cards> getAllCards() {
        List<Cards> allCards = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(cardFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 7) {
                    try {
                        // Kart bilgilerini parse ediyoruz
                        double balance = Double.parseDouble(parts[5].replace(",", ".")); // Bakiyeyi virgülden noktaya çeviriyoruz
                        boolean isActive = Boolean.parseBoolean(parts[6]); // Abonman durumu
                        Cards card = new Cards(parts[0], parts[1], parts[2], parts[3], parts[4], balance, isActive);
                        allCards.add(card);
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid balance format: " + parts[5]);
                    }
                } else {
                    System.err.println("Invalid data format: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return allCards;
    }

    public boolean isCardExists(String userId, String cardType) {
        try (BufferedReader reader = new BufferedReader(new FileReader(cardFile))) {
            String line;

            // Dosyadaki her satırı kontrol et
            while ((line = reader.readLine()) != null) {
                String[] cardData = line.split("\\|"); // Veriyi '|' ile ayırıyoruz
                String existingUserId = cardData[0];  // Kullanıcı ID'si
                String existingCardType = cardData[2]; // Kart tipi

                // Eğer aynı kullanıcı ve aynı kart türü mevcutsa, true döndür
                if (existingUserId.equals(userId) && existingCardType.equals(cardType)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Eğer hiçbir eşleşme bulunmazsa, false döndür
        return false;
    }







    public void updateCardBalance(String userId, String cardName, String cardNumber, double newBalance) {
        List<Cards> allCards = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(cardFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("Reading line: " + line);  // Okunan satırı göster
                String[] parts = line.split("\\|");

                if (parts.length >= 7) {  // Formatı kontrol et
                    try {
                        Cards card = new Cards(
                                parts[0], // userId
                                parts[1], // cardName
                                parts[2], // cardType
                                parts[3], // cardNumber
                                parts[4], // expiryDate
                                Double.parseDouble(parts[5].replace(",", ".")), // Bakiyeyi virgülden noktaya çevir
                                Boolean.parseBoolean(parts[6]) // isActive
                        );

                        System.out.println("Parsed card: " + card.toString()+" Kart Adı:    "+cardName);
                        System.out.println("user id: " + card.getUserId() + " vs given user id: " + userId);
                        System.out.println("card number: " + card.getCardNumber() + " vs given card number: " + cardNumber);

                        // Bakiye güncellemeyi kontrol et
                        if (card.getUserId().equals(userId) && card.getCardNumber().equals(cardNumber)) {
                            double updatedBalance = card.getBalance() + newBalance; // Eski bakiyeyi üzerine ekle
                            card.setBalance(updatedBalance); // Yeni bakiyeyi ayarla
                            System.out.println("Match found. Updating balance. New balance: " + updatedBalance);
                        }

                        allCards.add(card); // Kartı listeye ekle
                    } catch (Exception e) {
                        System.out.println("Error parsing card data: " + e.getMessage());
                    }
                } else {
                    System.out.println("Invalid card data format: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return; // Hata durumunda işlemi sonlandır
        }

        // Güncellenmiş kartları kontrol et
        System.out.println("Updated cards:");
        for (Cards card : allCards) {
            System.out.println(card.toString());
        }

        // Güncellenmiş listeyi dosyaya yazma işlemi
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(cardFile))) {
            System.out.println("Writing updated cards back to the file...");
            for (Cards card : allCards) {
                // Kartı dosyaya formatlı şekilde yaz (cardName eklendi)
                writer.write(String.format("%s|%s|%s|%s|%s|%.2f|%b",
                        card.getUserId(),
                        card.getCardName(), // Eksik olan cardName eklendi
                        card.getCardType(),
                        card.getCardNumber(),
                        card.getExpiryDate(),
                        card.getBalance(),
                        card.isSubscriptionStatus()
                ));
                writer.newLine();
            }
            System.out.println("Cards have been written back to the file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }












    // Kullanıcının sahip olduğu kartların bakiyesini günceller
//    public void updateCardBalance(String userId, String cardNumber, double newBalance) {
//        List<String> updatedLines = new ArrayList<>();
//        try (BufferedReader reader = new BufferedReader(new FileReader(cardFile))) {
//            String line;
//            while ((line = reader.readLine()) != null) {
//                String[] parts = line.split(" ");
//                if (parts.length > 5 && parts[0].equals(userId) && parts[2].equals(cardNumber)) {
//                    // Bakiye güncellenir
//                    parts[4] = String.valueOf(newBalance);
//                }
//                updatedLines.add(String.join(" ", parts));  // Güncellenmiş satır eklenir
//            }
//
//            // Dosyayı yeniden yaz
//            try (BufferedWriter writer = new BufferedWriter(new FileWriter(cardFile))) {
//                for (String updatedLine : updatedLines) {
//                    writer.write(updatedLine);
//                    writer.newLine(); // Yeni satır ekle
//                }
//            }
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

    // Kullanıcının sahip olduğu kartların abonman durumunu günceller

    public void updateSubscriptionStatus(String userId, String cardId, boolean newStatus) {
        List<Cards> allCards = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(cardFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 7) {
                    // Kartı oluştur
                    double balance = 0.0;
                    try {
                        balance = Double.parseDouble(parts[5].replace(",", ".")); // balance alanı dönüştürülüyor
                    } catch (NumberFormatException e) {
                        System.err.println("Geçersiz bakiye formatı: " + parts[5]);
                    }

                    // `Boolean.parseBoolean` yerine daha sağlam bir kontrol
                    boolean subscriptionStatus = false;
                    if ("true".equalsIgnoreCase(parts[6])) {
                        subscriptionStatus = true;
                    } else if ("false".equalsIgnoreCase(parts[6])) {
                        subscriptionStatus = false;
                    }

                    Cards card = new Cards(
                            parts[0],  // userId
                            parts[1],  // cardName
                            parts[2],  // cardType
                            parts[3],  // cardNumber
                            parts[4],  // expiryDate
                            balance,   // balance
                            subscriptionStatus  // subscriptionStatus
                    );

                    // Kullanıcı ID ve kart ID'si eşleşiyorsa abonman durumu güncellenir
                    if (card.getUserId().equals(userId) && card.getCardNumber().equals(cardId)) {
                        card.setSubscriptionStatus(newStatus); // Abonman durumu güncelleniyor
                        System.out.println("Abonman durumu güncelleniyor: " + card.getCardNumber() + " " + newStatus);
                    }

                    // Güncellenmiş kartları listeye ekle
                    allCards.add(card);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return; // Hata durumunda işlemi sonlandır
        }

        // Güncellenmiş kartları dosyaya yazma işlemi
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(cardFile))) {
            for (Cards card : allCards) {
                // Kart bilgilerini dosyaya yaz
                writer.write(String.format("%s|%s|%s|%s|%s|%.2f|%b",
                        card.getUserId(),
                        card.getCardName(),
                        card.getCardType(),
                        card.getCardNumber(),
                        card.getExpiryDate(),
                        card.getBalance(),
                        card.isSubscriptionStatus()
                ));
                writer.newLine();
            }
            System.out.println("Kart bilgileri dosyaya yazıldı.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public double getBalanceForUser(String userId) {
        double balance = 0.0;
        // Burada kullanıcıya ait kartları alıp bakiyeleri toplamanız gerekebilir.
        List<Cards> userCards = getCardsByUserId(userId);
        for (Cards card : userCards) {
            balance += card.getBalance(); // Örnek, kart bakiyelerini toplar
        }
        return balance;
    }

    public void deleteCard(String userId, String cardNumber) {
        List<Cards> allCards = new ArrayList<>();
        boolean cardFound = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(cardFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");

                if (parts.length >= 7) {
                    // Kartı oluştur
                    Cards card = new Cards(
                            parts[0],  // userId
                            parts[1],  // cardName
                            parts[2],  // cardType
                            parts[3],  // cardNumber
                            parts[4],  // expiryDate
                            Double.parseDouble(parts[5].replace(",", ".")), // balance
                            Boolean.parseBoolean(parts[6])  // subscriptionStatus
                    );

                    // Eğer kart eşleşiyorsa (silinecek kart ise) kartFound = true
                    if (card.getUserId().equals(userId) && card.getCardNumber().equals(cardNumber)) {
                        cardFound = true;
                        continue; // Bu kartı eklemeden geç
                    }

                    // Eşleşmeyen kartları listeye ekle
                    allCards.add(card);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (cardFound) {
            // Güncellenmiş kartları dosyaya yazma işlemi
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(cardFile))) {
                for (Cards card : allCards) {
                    // Kart bilgilerini dosyaya yaz
                    writer.write(String.format("%s|%s|%s|%s|%s|%.2f|%b",
                            card.getUserId(),
                            card.getCardName(),
                            card.getCardType(),
                            card.getCardNumber(),
                            card.getExpiryDate(),
                            card.getBalance(),
                            card.isSubscriptionStatus()
                    ));
                    writer.newLine();
                }
                System.out.println("Kart başarıyla silindi.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Silinecek kart bulunamadı.");
        }
    }





}
