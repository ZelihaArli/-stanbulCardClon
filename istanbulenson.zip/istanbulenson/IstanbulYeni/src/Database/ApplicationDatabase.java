package Database;

import Passengers.PassengerType;
import UI.Application;

import java.io.*;
import java.util.*;

public class ApplicationDatabase {
    private final String applicationFile;

    // Constructor with default file path
    public ApplicationDatabase() {
        this.applicationFile = "C:/Users/adema/Desktop/Projeler/applicationsDatabase.txt";  // default file location
        File file = new File(applicationFile);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to add an application to the database
    public void addApplication(String userId, String cardType, String applicationStatus, PassengerType passengerType,String document) {
        String applicationId = UUID.randomUUID().toString();  // Unique ID for the application
        String applicationDate = java.time.LocalDate.now().toString();  // Current date for the application

        // Save the application to the file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(applicationFile, true))) {
            String newApplication = String.join("|", applicationId, userId, applicationDate, cardType, applicationStatus, passengerType.name(),document);
            writer.write(newApplication);
            writer.newLine();  // Yeni başvuruyu dosyaya ekler
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // Method to read all applications from the database
    public List<Application> getAllApplications() {
        List<Application> applications = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(applicationFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split("\\|");

                // Verinin 7 parçaya bölündüğünden emin olalım
                if (data.length == 7) {  // 7 parça veri bekleniyor
                    String applicationId = data[0];
                    String userId = data[1];
                    String applicationDate = data[2];
                    String cardType = data[3];
                    String applicationStatus = data[4];
                    PassengerType passengerType;


                    // PassengerType enum değeri alınıyor
                    try {
                        passengerType = PassengerType.valueOf(data[5]);
                    } catch (IllegalArgumentException e) {
                        System.err.println("Hatalı PassengerType verisi: " + data[5]);
                        passengerType = PassengerType.ANONYMOUS; // Varsayılan bir değer atayın
                    }
                    String document=data[6];

                    // Yeni bir Application objesi oluşturuyoruz
                    applications.add(new Application(applicationId, userId, applicationDate, cardType, applicationStatus, passengerType,document));
                } else {
                    // Hatalı veri durumunda ne olduğunu görmek için
                    System.out.println("Geçersiz veri satırı: ");
                    for (String item : data) {
                        System.out.println(item);  // Veri öğelerini ekrana yazdırıyoruz
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return applications;
    }


    // Method to update the status of an application
//    public void updateApplicationStatus(String applicationId, String newStatus) {
//        File inputFile = new File(applicationFile);
//        File tempFile = new File("C:/Users/Taha/Desktop/Projeler/temp_applicationsDatabase.txt");
//
//        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
//             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
//
//            String line;
//            while ((line = reader.readLine()) != null) {
//                String[] data = line.split("\\|");
//
//                if (data[0].equals(applicationId)) {
//                    data[4] = newStatus;  // Durumu güncelle
//                }
//
//                writer.write(String.join("|", data));
//                writer.newLine();
//            }
//
//            // Orijinal dosyayı sil ve temp dosyasını yeniden adlandır
//            if (inputFile.delete()) {
//                if (tempFile.renameTo(inputFile)) {
//                    System.out.println("Dosya başarıyla güncellendi.");
//                } else {
//                    System.err.println("Geçici dosya yeniden adlandırılamadı!");
//                }
//            } else {
//                System.err.println("Orijinal dosya silinemedi!");
//            }
//
//
//
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

    public void updateApplicationStatus(String applicationId, String newStatus) {
        File inputFile = new File(applicationFile);
        File tempFile = new File(inputFile.getAbsolutePath() + ".tmp");

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split("\\|");
                if (data[0].equals(applicationId)) {
                    data[4] = newStatus; // Durumu güncelle
                }
                writer.write(String.join("|", data));
                writer.newLine();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Dosya işlemleri
        if (inputFile.delete()) {
            if (tempFile.renameTo(inputFile)) {
                System.out.println("Başvuru durumu güncellendi.");
            } else {
                System.err.println("Geçici dosya yeniden adlandırılamadı!");
            }
        } else {
            System.err.println("Orijinal dosya silinemedi!");
        }
    }



    // Inner class to represent an application

}
