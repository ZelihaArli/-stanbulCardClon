package Database;

import java.io.*;
        import java.util.*;
        import java.util.UUID;

public class AdminDatabase {
    private final String adminFile = "adminDatabase.txt";  // Dosya yolu burada sabitleniyor

    public AdminDatabase() {
        // Dosyanın varlığını kontrol et, yoksa oluştur
        File file = new File(adminFile);
        if (!file.exists()) {
            try {
                file.createNewFile();  // Dosya yoksa oluşturulacak
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Yeni admin ekler
    public void addAdmin(String name, String surname, String email, String password) {
        String adminId = UUID.randomUUID().toString();  // Rastgele benzersiz admin ID oluştur

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(adminFile, true))) {
            // Admin verisini dosyaya kaydet
            String newAdmin = adminId + "|" + name + "|" + surname + "|" + email + "|" + password;
            writer.write(newAdmin);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // E-posta ile şifreyi almak için fonksiyon
    public String getPasswordByEmail(String email) {
        try (BufferedReader reader = new BufferedReader(new FileReader(adminFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Admin bilgilerini al ve e-posta ile karşılaştır
                String[] adminFields = line.split("\\|");
                if (adminFields.length > 4 && adminFields[3].equals(email)) {
                    return adminFields[4]; // E-posta bulunduysa, şifreyi döndür
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null; // Eğer e-posta bulunamazsa, null döndür
    }

    // E-posta ile admin doğrular
    public boolean validateAdminLogin(String email, String password) {
        String storedPassword = getPasswordByEmail(email);
        return storedPassword != null && storedPassword.equals(password);
    }

    // Admin ID ile admin bilgilerini alır
    public List<String> getAdminById(String adminId) {
        return findLineById(adminFile, adminId);
    }

    // Dosyadan ID'ye göre satır bulur
    private List<String> findLineById(String filePath, String id) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(id + "|")) {
                    return List.of(line.split("\\|"));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Admin verilerini güncellemek için bir alanı değiştirir
    private void updateField(String filePath, String id, int fieldIndex, FieldUpdater updater) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath));
             BufferedWriter writer = new BufferedWriter(new FileWriter("temp.txt"))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts[0].equals(id)) {
                    parts[fieldIndex] = updater.update(parts[fieldIndex]);
                    line = String.join("|", parts);
                }
                writer.write(line);
                writer.newLine();
            }

            // Eski dosyayı sil ve yeni dosyayı yeniden adlandır
            new File(filePath).delete();
            new File("temp.txt").renameTo(new File(filePath));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Admin bilgilerini e-posta üzerinden alır
    public List<String> getAdminByEmail(String email) {
        try (BufferedReader reader = new BufferedReader(new FileReader(adminFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] adminFields = line.split("\\|");
                if (adminFields.length > 4 && adminFields[3].equals(email)) {
                    return List.of(adminFields);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @FunctionalInterface
    private interface FieldUpdater {
        String update(String currentValue);
    }
}
